"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { format } from "date-fns"
import { CalendarIcon, Upload, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import DocumentPreview from "@/components/document-preview"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

const formSchema = z.object({
  businessName: z.string().min(2, { message: "Business name is required" }),
  authorityName: z.string().min(2, { message: "Authority name is required" }),
  authorityFatherName: z.string().min(2, { message: "Authority father name is required" }),
  homeAddress: z.string().min(5, { message: "Home address is required" }),
  placeAddress: z.string().min(5, { message: "Place address is required" }),
  nomineeName: z.string().min(2, { message: "Nominee name is required" }),
  nomineeRelation: z.string().min(2, { message: "Nominee relation is required" }),
  date: z.date(),
  contactNo: z.string().min(10, { message: "Valid contact number is required" }),
  email: z.string().email({ message: "Valid email is required" }),
  partnershipType: z.enum(["single", "multiple"]).default("single"),
})

type FormValues = z.infer<typeof formSchema>

interface ExtendedFormValues extends FormValues {
  aadhaarFrontImage?: string
  aadhaarBackImage?: string
  panImage?: string
  stampImage?: string
  signatureImage?: string
  partners?: Partner[]
}

interface Partner {
  name: string
  address: string
  contact: string
  description: string
  idDetails: string
  appointmentDate: string
}

export default function TradingForm() {
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState<ExtendedFormValues | null>(null)

  // State for image uploads
  const [aadhaarFrontImage, setAadhaarFrontImage] = useState<string | null>(null)
  const [aadhaarBackImage, setAadhaarBackImage] = useState<string | null>(null)
  const [panImage, setPanImage] = useState<string | null>(null)
  const [stampImage, setStampImage] = useState<string | null>(null)
  const [signatureImage, setSignatureImage] = useState<string | null>(null)

  // State for partners
  const [partners, setPartners] = useState<Partner[]>([])
  const [partnershipType, setPartnershipType] = useState<"single" | "multiple">("single")

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      authorityName: "",
      authorityFatherName: "",
      homeAddress: "",
      placeAddress: "",
      nomineeName: "",
      nomineeRelation: "",
      date: new Date(),
      contactNo: "",
      email: "",
      partnershipType: "single",
    },
  })

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setImage: (value: string | null) => void) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Remove uploaded image
  const removeImage = (setImage: (value: string | null) => void) => {
    setImage(null)
  }

  // Add a new partner
  const addPartner = () => {
    setPartners([
      ...partners,
      {
        name: "",
        address: "",
        contact: "",
        description: "Partner",
        idDetails: "PAN CARD",
        appointmentDate: "",
      },
    ])
  }

  // Remove a partner
  const removePartner = (index: number) => {
    const updatedPartners = [...partners]
    updatedPartners.splice(index, 1)
    setPartners(updatedPartners)
  }

  // Update partner field
  const updatePartnerField = (index: number, field: keyof Partner, value: string) => {
    const updatedPartners = [...partners]
    updatedPartners[index][field] = value
    setPartners(updatedPartners)
  }

  function onSubmit(values: FormValues) {
    // Combine form values with uploaded images and partners
    const extendedValues: ExtendedFormValues = {
      ...values,
      aadhaarFrontImage: aadhaarFrontImage || undefined,
      aadhaarBackImage: aadhaarBackImage || undefined,
      panImage: panImage || undefined,
      stampImage: stampImage || undefined,
      signatureImage: signatureImage || undefined,
      partners: partnershipType === "multiple" ? partners : undefined,
    }

    setFormData(extendedValues)
    setShowPreview(true)
  }

  return (
    <div>
      {!showPreview ? (
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Trading Field Application</CardTitle>
            <CardDescription>
              Fill in the details to generate self-declaration, KYC, list of proprietorship, and authority letter.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Business Information</h3>
                  <FormField
                    control={form.control}
                    name="businessName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter business name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="placeAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Address</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter business address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter email address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Proprietor Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="authorityName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter proprietor name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="authorityFatherName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Father's Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter father's name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="homeAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Proprietor Home Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Enter home address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter contact number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Partnership Type</h3>
                  <FormField
                    control={form.control}
                    name="partnershipType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => {
                              field.onChange(value)
                              setPartnershipType(value as "single" | "multiple")
                            }}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="single" />
                              </FormControl>
                              <FormLabel className="font-normal">Single Proprietorship</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="multiple" />
                              </FormControl>
                              <FormLabel className="font-normal">Multiple Partners</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {partnershipType === "multiple" && (
                    <div className="space-y-4 mt-4">
                      <div className="flex justify-between items-center">
                        <h4 className="text-md font-medium">Partners</h4>
                        <Button type="button" onClick={addPartner} size="sm">
                          Add Partner
                        </Button>
                      </div>

                      {partners.map((partner, index) => (
                        <div key={index} className="border p-4 rounded-md">
                          <div className="flex justify-between items-center mb-4">
                            <h5 className="font-medium">Partner {index + 1}</h5>
                            <Button type="button" variant="destructive" size="sm" onClick={() => removePartner(index)}>
                              Remove
                            </Button>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium mb-1">Name</label>
                              <Input
                                value={partner.name}
                                onChange={(e) => updatePartnerField(index, "name", e.target.value)}
                                placeholder="Partner name"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Address</label>
                              <Input
                                value={partner.address}
                                onChange={(e) => updatePartnerField(index, "address", e.target.value)}
                                placeholder="Partner address"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Contact</label>
                              <Input
                                value={partner.contact}
                                onChange={(e) => updatePartnerField(index, "contact", e.target.value)}
                                placeholder="Contact number"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Description</label>
                              <Input
                                value={partner.description}
                                onChange={(e) => updatePartnerField(index, "description", e.target.value)}
                                placeholder="Partner description"
                                defaultValue="Partner"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Document Uploads</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Aadhaar Card Front Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Front)</label>
                      <div className="mt-2">
                        {!aadhaarFrontImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Front</p>
                            <label htmlFor="aadhaar-front-upload" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-front-upload").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-front-upload"
                                onChange={(e) => handleImageUpload(e, setAadhaarFrontImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarFrontImage || "/placeholder.svg"}
                              alt="Aadhaar Card Front"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarFrontImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Aadhaar Card Back Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Back)</label>
                      <div className="mt-2">
                        {!aadhaarBackImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Back</p>
                            <label htmlFor="aadhaar-back-upload" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-back-upload").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-back-upload"
                                onChange={(e) => handleImageUpload(e, setAadhaarBackImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarBackImage || "/placeholder.svg"}
                              alt="Aadhaar Card Back"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarBackImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* PAN Card Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">PAN Card</label>
                      <div className="mt-2">
                        {!panImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload PAN Card</p>
                            <label htmlFor="pan-upload" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("pan-upload").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="pan-upload"
                                onChange={(e) => handleImageUpload(e, setPanImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={panImage || "/placeholder.svg"}
                              alt="PAN Card"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setPanImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Stamp Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Business Stamp</label>
                      <div className="mt-2">
                        {!stampImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Business Stamp</p>
                            <label htmlFor="stamp-upload" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("stamp-upload").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="stamp-upload"
                                onChange={(e) => handleImageUpload(e, setStampImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={stampImage || "/placeholder.svg"}
                              alt="Business Stamp"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setStampImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Signature Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Signature</label>
                      <div className="mt-2">
                        {!signatureImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Signature</p>
                            <label htmlFor="signature-upload" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("signature-upload").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="signature-upload"
                                onChange={(e) => handleImageUpload(e, setSignatureImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={signatureImage || "/placeholder.svg"}
                              alt="Signature"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setSignatureImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Nominee Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="nomineeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nominee Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter nominee name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="nomineeRelation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Relationship with Proprietor</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter relationship" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Additional Information</h3>
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground",
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" className="w-full">
                  Generate Documents
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <DocumentPreview
          data={{ ...formData, partners: partners }}
          onBack={() => setShowPreview(false)}
          partnershipType={partnershipType}
        />
      )}
    </div>
  )
}
