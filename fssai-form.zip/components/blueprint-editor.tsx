"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Move, Plus, Trash2 } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface BlueprintEditorProps {
  backgroundImage?: string
  initialSections: Array<{
    id: string
    name: string
    enabled: boolean
    dimensions?: string
  }>
  onChange: (
    sections: Array<{
      id: string
      name: string
      enabled: boolean
      dimensions?: string
      position: { x: number; y: number }
    }>,
  ) => void
}

interface DraggableSection {
  id: string
  name: string
  enabled: boolean
  dimensions?: string
  position: { x: number; y: number }
}

export default function BlueprintEditor({ backgroundImage, initialSections, onChange }: BlueprintEditorProps) {
  const [sections, setSections] = useState<DraggableSection[]>(() =>
    initialSections
      .filter((section) => section.enabled)
      .map((section, index) => ({
        ...section,
        position: { x: 50 + index * 30, y: 50 + index * 30 },
        dimensions: section.dimensions || "",
      })),
  )

  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [startPos, setStartPos] = useState({ x: 0, y: 0 })
  const containerRef = useRef<HTMLDivElement>(null)

  // Track if a section is being edited to prevent drag during edit
  const [editingSection, setEditingSection] = useState<string | null>(null)

  // Update parent component when sections change
  useEffect(() => {
    onChange(sections)
  }, [sections, onChange])

  // Handle mouse down on a section
  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    e.preventDefault()
    if (editingSection === id) return // Don't start drag if editing
    setActiveSection(id)
    setStartPos({ x: e.clientX, y: e.clientY })
  }

  // Handle mouse move
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!activeSection) return

    const dx = e.clientX - startPos.x
    const dy = e.clientY - startPos.y

    setSections((prev) =>
      prev.map((section) => {
        if (section.id === activeSection) {
          return {
            ...section,
            position: {
              x: section.position.x + dx,
              y: section.position.y + dy,
            },
          }
        }
        return section
      }),
    )

    setStartPos({ x: e.clientX, y: e.clientY })
  }

  // Handle mouse up
  const handleMouseUp = () => {
    setActiveSection(null)
  }

  // Add a new section
  const addSection = () => {
    const newId = `section-${Date.now()}`
    const newSection: DraggableSection = {
      id: newId,
      name: "New Section",
      enabled: true,
      position: { x: 100, y: 100 },
    }
    setSections([...sections, newSection])
  }

  // Remove a section
  const removeSection = (id: string) => {
    setSections(sections.filter((section) => section.id !== id))
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-md font-medium">Blueprint Layout</h3>
        <Button type="button" size="sm" onClick={addSection} className="flex items-center gap-1">
          <Plus className="h-4 w-4" />
          Add Section
        </Button>
      </div>

      <div
        ref={containerRef}
        className="border-2 border-gray-300 rounded-lg relative"
        style={{ height: "500px", overflow: "hidden" }}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {backgroundImage && (
          <img
            src={backgroundImage || "/placeholder.svg"}
            alt="Blueprint Background"
            className="w-full h-full object-contain absolute top-0 left-0 opacity-30"
          />
        )}

        <div className="absolute top-0 left-0 w-full h-full">
          {sections.map((section) => (
            <div
              key={section.id}
              className="absolute bg-white border-2 border-blue-500 rounded p-2 shadow-md cursor-move"
              style={{
                left: `${section.position.x}px`,
                top: `${section.position.y}px`,
                minWidth: "120px",
                zIndex: activeSection === section.id ? 10 : 1,
              }}
              onMouseDown={(e) => handleMouseDown(e, section.id)}
            >
              <div className="flex items-center justify-between mb-1">
                <Move className="h-4 w-4 text-gray-500 mr-1" />
                <input
                  type="text"
                  value={section.name}
                  onChange={(e) => {
                    const updatedSections = sections.map((s) =>
                      s.id === section.id ? { ...s, name: e.target.value } : s,
                    )
                    setSections(updatedSections)
                  }}
                  className="font-medium text-sm bg-transparent border-b border-dashed border-gray-400 focus:outline-none focus:border-blue-500 w-full"
                  onClick={(e) => e.stopPropagation()}
                  onFocus={(e) => {
                    e.stopPropagation()
                    setEditingSection(section.id)
                  }}
                  onBlur={() => setEditingSection(null)}
                />
                <button
                  type="button"
                  className="ml-1 text-red-500 hover:text-red-700"
                  onClick={(e) => {
                    e.stopPropagation()
                    removeSection(section.id)
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
              <Input
                type="text"
                placeholder="Dimensions (optional)"
                value={section.dimensions || ""}
                onChange={(e) => {
                  const updatedSections = sections.map((s) =>
                    s.id === section.id ? { ...s, dimensions: e.target.value } : s,
                  )
                  setSections(updatedSections)
                }}
                className="text-xs mt-1 h-6 py-1 px-2"
                onClick={(e) => e.stopPropagation()}
                onFocus={(e) => {
                  e.stopPropagation()
                  setEditingSection(section.id)
                }}
                onBlur={() => setEditingSection(null)}
              />
            </div>
          ))}
        </div>

        <div className="absolute bottom-2 right-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              // Reset positions
              setSections((prev) =>
                prev.map((section, index) => ({
                  ...section,
                  position: { x: 50 + index * 30, y: 50 + index * 30 },
                })),
              )
            }}
          >
            Reset Layout
          </Button>
        </div>
      </div>
    </div>
  )
}
