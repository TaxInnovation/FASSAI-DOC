"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { format } from "date-fns"
import { CalendarIcon, GripVertical, Maximize2, Minimize2, Upload, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import DocumentPreview from "@/components/document-preview"
import { Checkbox } from "@/components/ui/checkbox"
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd"
import BlueprintEditor from "@/components/blueprint-editor"

const formSchema = z.object({
  businessName: z.string().min(2, { message: "Business name is required" }),
  authorityName: z.string().min(2, { message: "Authority name is required" }),
  authorityFatherName: z.string().min(2, { message: "Authority father name is required" }),
  homeAddress: z.string().min(5, { message: "Home address is required" }),
  placeAddress: z.string().min(5, { message: "Place address is required" }),
  nomineeName: z.string().min(2, { message: "Nominee name is required" }),
  nomineeRelation: z.string().min(2, { message: "Nominee relation is required" }),
  date: z.date(),
  contactNo: z.string().min(10, { message: "Valid contact number is required" }),
  email: z.string().email({ message: "Valid email is required" }),
  gstin: z.string().optional(),
  // Additional manufacturing fields
  productType: z.string().min(2, { message: "Product type is required" }),
  manufacturingCapacity: z.string().min(1, { message: "Manufacturing capacity is required" }),
  // New fields for blueprint layout
  facilityDimensions: z.string().optional(),
  rawMaterialArea: z.string().optional(),
  productionArea: z.string().optional(),
  finishedGoodsArea: z.string().optional(),
  packingArea: z.string().optional(),
  adminArea: z.string().optional(),
  // Equipment list
  equipmentList: z
    .array(
      z.object({
        name: z.string(),
        powerLoad: z.string().optional(),
        quantity: z.string(),
        capacity: z.string(),
        image: z.string().optional(),
      }),
    )
    .optional(),
})

type FormValues = z.infer<typeof formSchema>

interface ExtendedFormValues extends FormValues {
  aadhaarFrontImage?: string
  aadhaarBackImage?: string
  panImage?: string
  stampImage?: string
  signatureImage?: string
  blueprintImage?: string
  blueprintItems?: Array<{
    id: string
    type: string
    name: string
    position: { x: number; y: number }
  }>
  blueprintSectionsWithPositions?: Array<{
    id: string
    name: string
    enabled: boolean
    dimensions?: string
    position: { x: number; y: number }
  }>
}

export default function ManufacturingForm() {
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState<ExtendedFormValues | null>(null)

  // State for image uploads
  const [aadhaarFrontImage, setAadhaarFrontImage] = useState<string | null>(null)
  const [aadhaarBackImage, setAadhaarBackImage] = useState<string | null>(null)
  const [panImage, setPanImage] = useState<string | null>(null)
  const [stampImage, setStampImage] = useState<string | null>(null)
  const [signatureImage, setSignatureImage] = useState<string | null>(null)

  // Add this after other state declarations
  const [blueprintImage, setBlueprintImage] = useState<string | null>(null)
  const [blueprintItems, setBlueprintItems] = useState<
    Array<{
      id: string
      type: string
      name: string
      position: { x: number; y: number }
    }>
  >([])

  // Add this after other state declarations
  const [blueprintSectionsWithPositions, setBlueprintSectionsWithPositions] = useState<
    Array<{
      id: string
      name: string
      enabled: boolean
      dimensions?: string
      position: { x: number; y: number }
    }>
  >([])

  // State for blueprint layout customization
  const [blueprintSections, setBlueprintSections] = useState([
    { id: "rawMaterial", name: "Raw Material Storage Area", enabled: true, expanded: true, order: 0 },
    { id: "production", name: "Production Area", enabled: true, expanded: true, order: 1 },
    { id: "finishedGoods", name: "Finished Goods Storage Area", enabled: true, expanded: true, order: 2 },
    { id: "packing", name: "Packing and Dispatch Area", enabled: true, expanded: true, order: 3 },
    { id: "admin", name: "Admin Office/Cabin", enabled: true, expanded: true, order: 4 },
  ])

  // Toggle section visibility
  const toggleSectionEnabled = (id: string) => {
    setBlueprintSections(
      blueprintSections.map((section) => (section.id === id ? { ...section, enabled: !section.enabled } : section)),
    )
  }

  // Toggle section expansion
  const toggleSectionExpanded = (id: string) => {
    setBlueprintSections(
      blueprintSections.map((section) => (section.id === id ? { ...section, expanded: !section.expanded } : section)),
    )
  }

  // Handle drag and drop reordering
  const handleDragEnd = (result: any) => {
    if (!result.destination) return

    const items = Array.from(blueprintSections)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    // Update order property
    const updatedItems = items.map((item, index) => ({
      ...item,
      order: index,
    }))

    setBlueprintSections(updatedItems)
  }

  // State for equipment list
  const [equipmentList, setEquipmentList] = useState<
    Array<{
      name: string
      powerLoad: string
      quantity: string
      capacity: string
      image: string
    }>
  >([{ name: "", powerLoad: "", quantity: "", capacity: "", image: "" }])

  // Add equipment item
  const addEquipmentItem = () => {
    setEquipmentList([...equipmentList, { name: "", powerLoad: "", quantity: "", capacity: "", image: "" }])
  }

  // Remove equipment item
  const removeEquipmentItem = (index: number) => {
    const updatedList = [...equipmentList]
    updatedList.splice(index, 1)
    setEquipmentList(updatedList)
  }

  // Update equipment item field
  const updateEquipmentField = (index: number, field: string, value: string) => {
    const updatedList = [...equipmentList]
    updatedList[index] = { ...updatedList[index], [field]: value }
    setEquipmentList(updatedList)
  }

  // Handle equipment image upload
  const handleEquipmentImageUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const updatedList = [...equipmentList]
        updatedList[index] = { ...updatedList[index], image: reader.result as string }
        setEquipmentList(updatedList)
      }
      reader.readAsDataURL(file)
    }
  }

  // Remove equipment image
  const removeEquipmentImage = (index: number) => {
    const updatedList = [...equipmentList]
    updatedList[index] = { ...updatedList[index], image: "" }
    setEquipmentList(updatedList)
  }

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      authorityName: "",
      authorityFatherName: "",
      homeAddress: "",
      placeAddress: "",
      nomineeName: "",
      nomineeRelation: "",
      date: new Date(),
      contactNo: "",
      email: "",
      gstin: "",
      productType: "",
      manufacturingCapacity: "",
    },
  })

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setImage: (value: string | null) => void) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Remove uploaded image
  const removeImage = (setImage: (value: string | null) => void) => {
    setImage(null)
  }

  // Add this with the other handler functions
  const handleBlueprintImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setBlueprintImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Add this function to remove blueprint image
  const removeBlueprintImage = () => {
    setBlueprintImage(null)
  }

  // Modify the onSubmit function to include blueprintImage
  function onSubmit(values: FormValues) {
    // Combine form values with uploaded images and equipment list
    const extendedValues: ExtendedFormValues = {
      ...values,
      aadhaarFrontImage: aadhaarFrontImage || undefined,
      aadhaarBackImage: aadhaarBackImage || undefined,
      panImage: panImage || undefined,
      stampImage: stampImage || undefined,
      signatureImage: signatureImage || undefined,
      equipmentList: equipmentList.length > 0 ? equipmentList : undefined,
      blueprintImage: blueprintImage || undefined,
      blueprintSectionsWithPositions:
        blueprintSectionsWithPositions.length > 0 ? blueprintSectionsWithPositions : undefined,
    }

    // Add blueprint layout configuration
    const blueprintConfig = {
      sections: blueprintSections,
    }

    setFormData({ ...extendedValues, blueprintConfig })
    setShowPreview(true)
  }

  return (
    <div>
      {!showPreview ? (
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Manufacturing Field Application</CardTitle>
            <CardDescription>
              Fill in the details to generate self-declaration, KYC, list of proprietorship, and authority letter.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Business Information</h3>
                  <FormField
                    control={form.control}
                    name="businessName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter business name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="gstin"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GSTIN (optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter GSTIN number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="placeAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Address</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter business address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter email address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Manufacturing Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="productType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Type</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter product type" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="manufacturingCapacity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Manufacturing Capacity</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter capacity" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Proprietor Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="authorityName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter proprietor name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="authorityFatherName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Father's Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter father's name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="homeAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Proprietor Home Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Enter home address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter contact number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Blueprint Layout</h3>
                    <p className="text-sm text-gray-500">Customize your facility layout</p>
                  </div>

                  <FormField
                    control={form.control}
                    name="facilityDimensions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Total Facility Dimensions</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 175*42 ft" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Find the blueprint layout section and add this after the facility dimensions field */}
                  <div className="space-y-4 mt-4">
                    <h4 className="font-medium">Blueprint Background Image (optional)</h4>
                    <div className="mt-2">
                      {!blueprintImage ? (
                        <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                          <Upload className="h-8 w-8 text-gray-400 mb-2" />
                          <p className="text-sm text-gray-500 mb-2">Click to upload Blueprint Background Image</p>
                          <label htmlFor="blueprint-image-upload" className="cursor-pointer">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => document.getElementById("blueprint-image-upload").click()}
                            >
                              Select Image
                            </Button>
                            <Input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              id="blueprint-image-upload"
                              onChange={handleBlueprintImageUpload}
                            />
                          </label>
                        </div>
                      ) : (
                        <div className="relative">
                          <img
                            src={blueprintImage || "/placeholder.svg"}
                            alt="Blueprint Background"
                            className="w-full h-auto object-contain border rounded-lg"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2 h-6 w-6"
                            onClick={removeBlueprintImage}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-500">
                      Upload a background image for your facility blueprint. You can then arrange sections on top of it.
                    </p>
                  </div>

                  {/* Add this after the blueprint image upload section */}
                  <div className="space-y-4 mt-4">
                    <h4 className="font-medium">Blueprint Layout Editor</h4>
                    <p className="text-sm text-gray-500 mb-2">
                      Use the editor below to create your facility layout. You can add new sections, rename them, set
                      dimensions, and drag them to position.
                    </p>
                    <BlueprintEditor
                      backgroundImage={blueprintImage || undefined}
                      initialSections={blueprintSections.map((section) => ({
                        id: section.id,
                        name: section.name,
                        enabled: section.enabled,
                        dimensions:
                          section.id === "rawMaterial"
                            ? form.getValues("rawMaterialArea")
                            : section.id === "production"
                              ? form.getValues("productionArea")
                              : section.id === "finishedGoods"
                                ? form.getValues("finishedGoodsArea")
                                : section.id === "packing"
                                  ? form.getValues("packingArea")
                                  : section.id === "admin"
                                    ? form.getValues("adminArea")
                                    : undefined,
                      }))}
                      onChange={setBlueprintSectionsWithPositions}
                    />
                    <p className="text-sm text-gray-500">
                      Tip: Click on section names to edit them. Use the trash icon to remove sections. Click "Add
                      Section" to add new areas.
                    </p>
                  </div>

                  <div className="border rounded-md p-4">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium">Layout Sections</h4>
                      <p className="text-sm text-gray-500">Drag to reorder, toggle to show/hide</p>
                    </div>

                    <DragDropContext onDragEnd={handleDragEnd}>
                      <Droppable droppableId="blueprint-sections">
                        {(provided) => (
                          <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                            {blueprintSections
                              .sort((a, b) => a.order - b.order)
                              .map((section, index) => (
                                <Draggable key={section.id} draggableId={section.id} index={index}>
                                  {(provided) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      className="border rounded-md p-3"
                                    >
                                      <div className="flex justify-between items-center">
                                        <div className="flex items-center gap-2">
                                          <div {...provided.dragHandleProps} className="cursor-move">
                                            <GripVertical className="h-5 w-5 text-gray-400" />
                                          </div>
                                          <Checkbox
                                            id={`enable-${section.id}`}
                                            checked={section.enabled}
                                            onCheckedChange={() => toggleSectionEnabled(section.id)}
                                          />
                                          <label
                                            htmlFor={`enable-${section.id}`}
                                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                          >
                                            {section.name}
                                          </label>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <Button
                                            type="button"
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => toggleSectionExpanded(section.id)}
                                          >
                                            {section.expanded ? (
                                              <Minimize2 className="h-4 w-4" />
                                            ) : (
                                              <Maximize2 className="h-4 w-4" />
                                            )}
                                          </Button>
                                        </div>
                                      </div>

                                      {section.expanded && section.enabled && (
                                        <div className="mt-2 pl-7">
                                          {section.id === "rawMaterial" && (
                                            <FormField
                                              control={form.control}
                                              name="rawMaterialArea"
                                              render={({ field }) => (
                                                <FormItem>
                                                  <FormLabel>Raw Material Storage Area Dimensions</FormLabel>
                                                  <FormControl>
                                                    <Input placeholder="e.g., 20 ft x 40 ft" {...field} />
                                                  </FormControl>
                                                  <FormMessage />
                                                </FormItem>
                                              )}
                                            />
                                          )}

                                          {section.id === "production" && (
                                            <FormField
                                              control={form.control}
                                              name="productionArea"
                                              render={({ field }) => (
                                                <FormItem>
                                                  <FormLabel>Production Area Dimensions</FormLabel>
                                                  <FormControl>
                                                    <Input placeholder="e.g., 80 ft x 40 ft" {...field} />
                                                  </FormControl>
                                                  <FormMessage />
                                                </FormItem>
                                              )}
                                            />
                                          )}

                                          {section.id === "finishedGoods" && (
                                            <FormField
                                              control={form.control}
                                              name="finishedGoodsArea"
                                              render={({ field }) => (
                                                <FormItem>
                                                  <FormLabel>Finished Goods Storage Area Dimensions</FormLabel>
                                                  <FormControl>
                                                    <Input placeholder="e.g., 20 ft x 40 ft" {...field} />
                                                  </FormControl>
                                                  <FormMessage />
                                                </FormItem>
                                              )}
                                            />
                                          )}

                                          {section.id === "packing" && (
                                            <FormField
                                              control={form.control}
                                              name="packingArea"
                                              render={({ field }) => (
                                                <FormItem>
                                                  <FormLabel>Packing and Dispatch Area Dimensions</FormLabel>
                                                  <FormControl>
                                                    <Input placeholder="e.g., 20 ft x 20 ft" {...field} />
                                                  </FormControl>
                                                  <FormMessage />
                                                </FormItem>
                                              )}
                                            />
                                          )}

                                          {section.id === "admin" && (
                                            <FormField
                                              control={form.control}
                                              name="adminArea"
                                              render={({ field }) => (
                                                <FormItem>
                                                  <FormLabel>Admin Office/Cabin Dimensions</FormLabel>
                                                  <FormControl>
                                                    <Input placeholder="e.g., 12 ft x 20 ft" {...field} />
                                                  </FormControl>
                                                  <FormMessage />
                                                </FormItem>
                                              )}
                                            />
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </Draggable>
                              ))}
                            {provided.placeholder}
                          </div>
                        )}
                      </Droppable>
                    </DragDropContext>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Equipment and Machinery List</h3>
                    <Button type="button" onClick={addEquipmentItem} size="sm" variant="outline">
                      Add Equipment
                    </Button>
                  </div>

                  {equipmentList.map((equipment, index) => (
                    <div key={index} className="border p-4 rounded-md">
                      <div className="flex justify-between items-center mb-4">
                        <h5 className="font-medium">Equipment {index + 1}</h5>
                        {equipmentList.length > 1 && (
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            onClick={() => removeEquipmentItem(index)}
                          >
                            Remove
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Equipment/Machinery Name</label>
                          <Input
                            value={equipment.name}
                            onChange={(e) => updateEquipmentField(index, "name", e.target.value)}
                            placeholder="e.g., Washer, Roaster, etc."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Power Load (optional)</label>
                          <Input
                            value={equipment.powerLoad}
                            onChange={(e) => updateEquipmentField(index, "powerLoad", e.target.value)}
                            placeholder="e.g., Voltage, HP"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Quantity</label>
                          <Input
                            value={equipment.quantity}
                            onChange={(e) => updateEquipmentField(index, "quantity", e.target.value)}
                            placeholder="e.g., 1, 2, etc."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Installed Capacity</label>
                          <Input
                            value={equipment.capacity}
                            onChange={(e) => updateEquipmentField(index, "capacity", e.target.value)}
                            placeholder="e.g., 500 kg/hr"
                          />
                        </div>
                      </div>

                      {/* Equipment Image Upload */}
                      <div className="mt-4">
                        <label className="block text-sm font-medium mb-1">Equipment Image (optional)</label>
                        <div className="mt-2">
                          {!equipment.image ? (
                            <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                              <Upload className="h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500 mb-2">Click to upload Equipment Image</p>
                              <label htmlFor={`equipment-image-${index}`} className="cursor-pointer">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => document.getElementById(`equipment-image-${index}`).click()}
                                >
                                  Select Image
                                </Button>
                                <Input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  id={`equipment-image-${index}`}
                                  onChange={(e) => handleEquipmentImageUpload(e, index)}
                                />
                              </label>
                            </div>
                          ) : (
                            <div className="relative">
                              <img
                                src={equipment.image || "/placeholder.svg"}
                                alt={`${equipment.name} Image`}
                                className="w-full h-40 object-contain border rounded-lg"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                className="absolute top-2 right-2 h-6 w-6"
                                onClick={() => removeEquipmentImage(index)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Document Uploads</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Aadhaar Card Front Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Front)</label>
                      <div className="mt-2">
                        {!aadhaarFrontImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Front</p>
                            <label htmlFor="aadhaar-front-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-front-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-front-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setAadhaarFrontImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarFrontImage || "/placeholder.svg"}
                              alt="Aadhaar Card Front"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarFrontImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Aadhaar Card Back Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Back)</label>
                      <div className="mt-2">
                        {!aadhaarBackImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Back</p>
                            <label htmlFor="aadhaar-back-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-back-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-back-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setAadhaarBackImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarBackImage || "/placeholder.svg"}
                              alt="Aadhaar Card Back"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarBackImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* PAN Card Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">PAN Card</label>
                      <div className="mt-2">
                        {!panImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload PAN Card</p>
                            <label htmlFor="pan-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("pan-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="pan-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setPanImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={panImage || "/placeholder.svg"}
                              alt="PAN Card"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setPanImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Stamp Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Business Stamp</label>
                      <div className="mt-2">
                        {!stampImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Business Stamp</p>
                            <label htmlFor="stamp-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("stamp-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="stamp-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setStampImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={stampImage || "/placeholder.svg"}
                              alt="Business Stamp"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setStampImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Signature Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Signature</label>
                      <div className="mt-2">
                        {!signatureImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Signature</p>
                            <label htmlFor="signature-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("signature-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="signature-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setSignatureImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={signatureImage || "/placeholder.svg"}
                              alt="Signature"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setSignatureImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Nominee Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="nomineeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nominee Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter nominee name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="nomineeRelation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Relationship with Proprietor</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter relationship" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Additional Information</h3>
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground",
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" className="w-full">
                  Generate Documents
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <DocumentPreview data={formData} onBack={() => setShowPreview(false)} isManufacturing={true} />
      )}
    </div>
  )
}
