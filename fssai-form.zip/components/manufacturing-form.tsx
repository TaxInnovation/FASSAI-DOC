"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { format } from "date-fns"
import { CalendarIcon, Upload, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import DocumentPreview from "@/components/document-preview"

const formSchema = z.object({
  businessName: z.string().min(2, { message: "Business name is required" }),
  authorityName: z.string().min(2, { message: "Authority name is required" }),
  authorityFatherName: z.string().min(2, { message: "Authority father name is required" }),
  homeAddress: z.string().min(5, { message: "Home address is required" }),
  placeAddress: z.string().min(5, { message: "Place address is required" }),
  nomineeName: z.string().min(2, { message: "Nominee name is required" }),
  nomineeRelation: z.string().min(2, { message: "Nominee relation is required" }),
  date: z.date(),
  contactNo: z.string().min(10, { message: "Valid contact number is required" }),
  email: z.string().email({ message: "Valid email is required" }),
  // Additional manufacturing fields
  productType: z.string().min(2, { message: "Product type is required" }),
  manufacturingCapacity: z.string().min(1, { message: "Manufacturing capacity is required" }),
})

type FormValues = z.infer<typeof formSchema>

interface ExtendedFormValues extends FormValues {
  aadhaarFrontImage?: string
  aadhaarBackImage?: string
  panImage?: string
  stampImage?: string
  signatureImage?: string
}

export default function ManufacturingForm() {
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState<ExtendedFormValues | null>(null)

  // State for image uploads
  const [aadhaarFrontImage, setAadhaarFrontImage] = useState<string | null>(null)
  const [aadhaarBackImage, setAadhaarBackImage] = useState<string | null>(null)
  const [panImage, setPanImage] = useState<string | null>(null)
  const [stampImage, setStampImage] = useState<string | null>(null)
  const [signatureImage, setSignatureImage] = useState<string | null>(null)

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      authorityName: "",
      authorityFatherName: "",
      homeAddress: "",
      placeAddress: "",
      nomineeName: "",
      nomineeRelation: "",
      date: new Date(),
      contactNo: "",
      email: "",
      productType: "",
      manufacturingCapacity: "",
    },
  })

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setImage: (value: string | null) => void) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  // Remove uploaded image
  const removeImage = (setImage: (value: string | null) => void) => {
    setImage(null)
  }

  function onSubmit(values: FormValues) {
    // Combine form values with uploaded images
    const extendedValues: ExtendedFormValues = {
      ...values,
      aadhaarFrontImage: aadhaarFrontImage || undefined,
      aadhaarBackImage: aadhaarBackImage || undefined,
      panImage: panImage || undefined,
      stampImage: stampImage || undefined,
      signatureImage: signatureImage || undefined,
    }

    setFormData(extendedValues)
    setShowPreview(true)
  }

  return (
    <div>
      {!showPreview ? (
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Manufacturing Field Application</CardTitle>
            <CardDescription>
              Fill in the details to generate self-declaration, KYC, list of proprietorship, and authority letter.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Business Information</h3>
                  <FormField
                    control={form.control}
                    name="businessName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter business name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="placeAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Address</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter business address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter email address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Manufacturing Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="productType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Type</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter product type" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="manufacturingCapacity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Manufacturing Capacity</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter capacity" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Proprietor Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="authorityName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter proprietor name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="authorityFatherName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Proprietor Father's Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter father's name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="homeAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Proprietor Home Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Enter home address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter contact number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Document Uploads</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Aadhaar Card Front Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Front)</label>
                      <div className="mt-2">
                        {!aadhaarFrontImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Front</p>
                            <label htmlFor="aadhaar-front-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-front-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-front-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setAadhaarFrontImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarFrontImage || "/placeholder.svg"}
                              alt="Aadhaar Card Front"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarFrontImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Aadhaar Card Back Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Aadhaar Card (Back)</label>
                      <div className="mt-2">
                        {!aadhaarBackImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Aadhaar Card Back</p>
                            <label htmlFor="aadhaar-back-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("aadhaar-back-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="aadhaar-back-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setAadhaarBackImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={aadhaarBackImage || "/placeholder.svg"}
                              alt="Aadhaar Card Back"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setAadhaarBackImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* PAN Card Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">PAN Card</label>
                      <div className="mt-2">
                        {!panImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload PAN Card</p>
                            <label htmlFor="pan-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("pan-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="pan-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setPanImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={panImage || "/placeholder.svg"}
                              alt="PAN Card"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setPanImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Stamp Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Business Stamp</label>
                      <div className="mt-2">
                        {!stampImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Business Stamp</p>
                            <label htmlFor="stamp-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("stamp-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="stamp-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setStampImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={stampImage || "/placeholder.svg"}
                              alt="Business Stamp"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setStampImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Signature Upload */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Signature</label>
                      <div className="mt-2">
                        {!signatureImage ? (
                          <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Click to upload Signature</p>
                            <label htmlFor="signature-upload-manufacturing" className="cursor-pointer">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById("signature-upload-manufacturing").click()}
                              >
                                Select Image
                              </Button>
                              <Input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                id="signature-upload-manufacturing"
                                onChange={(e) => handleImageUpload(e, setSignatureImage)}
                              />
                            </label>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={signatureImage || "/placeholder.svg"}
                              alt="Signature"
                              className="w-full h-40 object-contain border rounded-lg"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removeImage(setSignatureImage)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Nominee Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="nomineeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nominee Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter nominee name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="nomineeRelation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Relationship with Proprietor</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter relationship" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Additional Information</h3>
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground",
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="submit" className="w-full">
                  Generate Documents
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <DocumentPreview data={formData} onBack={() => setShowPreview(false)} isManufacturing={true} />
      )}
    </div>
  )
}
