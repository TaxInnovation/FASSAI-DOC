"use client"

import { useState } from "react"
import { format } from "date-fns"
import { ArrowLeft, Download, Maximize2, Minimize2, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { Input } from "@/components/ui/input"

// Define proper types for the component props
interface DocumentPreviewProps {
  data: any
  onBack: () => void
  isManufacturing?: boolean
  partnershipType?: "single" | "multiple"
}

// Update the interface to include the new fields
// Add to the ExtendedFormValues interface
interface FormValues {
  businessName: string
  placeAddress: string
  email: string
  contactNo: string
  authorityName: string
  authorityFatherName: string
  homeAddress: string
  nomineeName: string
  nomineeRelation: string
  date: Date | string | undefined
  productType?: string
  manufacturingCapacity?: string
  gstin?: string
}

interface ExtendedFormValues extends FormValues {
  aadhaarFrontImage?: string
  aadhaarBackImage?: string
  panImage?: string
  stampImage?: string
  signatureImage?: string
  partners?: Partner[]
  // New fields for blueprint and equipment
  facilityDimensions?: string
  rawMaterialArea?: string
  productionArea?: string
  finishedGoodsArea?: string
  packingArea?: string
  adminArea?: string
  blueprintConfig?: {
    sections: Array<{
      id: string
      name: string
      enabled: boolean
      expanded: boolean
      order: number
    }>
  }
  blueprintImage?: string
  blueprintSectionsWithPositions?: Array<{
    id: string
    name: string
    enabled: boolean
    dimensions?: string
    position: { x: number; y: number }
  }>
  equipmentList?: Array<{
    name: string
    powerLoad: string
    quantity: string
    capacity: string
    image: string
  }>
}

interface Partner {
  name: string
  address: string
  contact: string
  description: string
  idDetails: string
  appointmentDate: string
}

export default function DocumentPreview({
  data,
  onBack,
  isManufacturing = false,
  partnershipType = "single",
}: DocumentPreviewProps) {
  const [activeTab, setActiveTab] = useState("self-declaration")
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const [ownerName, setOwnerName] = useState<string>(data?.authorityName || "")

  // State for blueprint layout sections
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    rawMaterial: true,
    production: true,
    finishedGoods: true,
    packing: true,
    admin: true,
  })

  // Toggle section expansion in the preview
  const toggleSectionExpanded = (id: string) => {
    setExpandedSections({
      ...expandedSections,
      [id]: !expandedSections[id],
    })
  }

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return ""
    return format(new Date(date), "dd/MM/yyyy")
  }

  // If data is null, show a loading state or error message
  if (!data) {
    return (
      <div className="flex justify-center items-center h-64">
        <p>No data available. Please go back and fill the form.</p>
        <Button variant="outline" onClick={onBack} className="ml-4">
          Back to Form
        </Button>
      </div>
    )
  }

  // Function to handle printing
  const handlePrint = () => {
    window.print()
  }

  // Function to handle PDF download for KYC with multiple pages
  const handleKycDownload = async () => {
    setIsGeneratingPdf(true)

    try {
      const pdf = new jsPDF("p", "mm", "a4")
      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm

      // Generate Aadhaar Front Page - Full page image only
      if (data.aadhaarFrontImage) {
        // Create a temporary div with just the image
        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.aadhaarFrontImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate Aadhaar Back Page - Full page image only
      if (data.aadhaarBackImage) {
        pdf.addPage()

        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.aadhaarBackImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate PAN Card Page - Full page image only
      if (data.panImage) {
        pdf.addPage()

        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.panImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate KYC Info Page
      pdf.addPage()
      const kycInfoElement = document.getElementById("kyc-info-print")
      if (kycInfoElement) {
        const canvas = await html2canvas(kycInfoElement, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight)
      }

      // Add page numbers to KYC PDF
      const totalPages = pdf.getNumberOfPages()
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i)
        pdf.setFontSize(10)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Page ${i} of ${totalPages}`, imgWidth - 30, pageHeight - 10)
      }

      pdf.save(`${data.businessName}-KYC-Documents.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to handle PDF download for regular documents
  const handleDownload = async (elementId: string, fileName: string) => {
    setIsGeneratingPdf(true)

    try {
      const element = document.getElementById(elementId)
      if (!element) {
        console.error(`Element with ID ${elementId} not found`)
        return
      }

      // Clone the element to apply formatting without affecting the original
      const tempDiv = document.createElement("div")
      tempDiv.style.width = "800px" // Set a fixed width for better quality
      tempDiv.style.padding = "30px"
      tempDiv.style.backgroundColor = "#ffffff"
      tempDiv.style.fontFamily = "Arial, sans-serif"

      // Clone the content
      const contentClone = element.cloneNode(true) as HTMLElement

      // Apply additional styling for better formatting
      const paragraphs = contentClone.querySelectorAll("p")
      paragraphs.forEach((p) => {
        if (p.textContent?.includes("Mail ID:") || p.classList.contains("whitespace-pre-line")) {
          p.style.textAlign = "center"
          p.style.width = "100%"
        } else if (p.classList.contains("font-semibold") && p.textContent?.includes("TO WHOMSOEVER")) {
          p.style.textAlign = "center"
          p.style.width = "100%"
          p.style.display = "block"
          p.style.marginLeft = "auto"
          p.style.marginRight = "auto"
        } else {
          p.style.textAlign = "justify"
        }
        p.style.marginBottom = "10px"
        p.style.lineHeight = "1.5"
      })

      // Ensure headers are centered
      const headers = contentClone.querySelectorAll("h1, h2")
      headers.forEach((h) => {
        h.style.textAlign = "center"
        h.style.width = "100%"
      })

      // Ensure the TO WHOMSOEVER IT MAY CONCERN is centered
      const concernDiv = contentClone.querySelector(".concern-text")
      if (concernDiv) {
        concernDiv.setAttribute("style", "text-align: center; width: 100%; margin: 0 auto;")
      }

      // Special handling for recall plan and form IX to ensure proper formatting
      if (elementId === "recall-plan-print" || elementId === "form-ix-print") {
        tempDiv.style.width = "700px" // Narrower width for better text flow
        tempDiv.style.padding = "40px"

        // Improve list formatting
        const listItems = contentClone.querySelectorAll("ul li")
        listItems.forEach((li) => {
          li.style.marginBottom = "8px"
          li.style.textAlign = "left"
        })

        // Improve table formatting
        const tables = contentClone.querySelectorAll("table")
        tables.forEach((table) => {
          table.style.width = "100%"
          table.style.tableLayout = "fixed"
          table.style.marginBottom = "20px"
        })
      }

      tempDiv.appendChild(contentClone)
      document.body.appendChild(tempDiv)

      const canvas = await html2canvas(tempDiv, {
        scale: 4,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: "#ffffff",
      })

      document.body.removeChild(tempDiv)

      const imgData = canvas.toDataURL("image/png")

      // Calculate dimensions to maintain aspect ratio
      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      const pdf = new jsPDF("p", "mm", "a4")

      let heightLeft = imgHeight
      let position = 0

      // Add first page
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      // Add additional pages if needed
      let pageCount = 1
      while (heightLeft > 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pageCount++
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      // Add page numbers
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i)
        pdf.setFontSize(10)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Page ${i} of ${pageCount}`, imgWidth - 30, pageHeight - 10)
      }

      pdf.save(`${fileName}.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to generate a complete proprietorship document as a single image
  const generateCompleteProprietorshipPDF = async () => {
    setIsGeneratingPdf(true)

    try {
      // Get the entire proprietorship content
      const element = document.getElementById("proprietorship-print")
      if (!element) {
        console.error("Proprietorship element not found")
        return
      }

      // Create a temporary div to hold the content for rendering
      const tempDiv = document.createElement("div")
      tempDiv.style.width = "800px" // Reduced width for better fit on one page
      tempDiv.style.padding = "20px"
      tempDiv.style.backgroundColor = "#ffffff"
      tempDiv.style.fontFamily = "Arial, sans-serif"

      // Clone the content to avoid modifying the original
      const contentClone = element.cloneNode(true) as HTMLElement

      // Apply additional styling to ensure proper formatting
      const paragraphs = contentClone.querySelectorAll("p")
      paragraphs.forEach((p) => {
        // For address and contact info in the header, preserve line breaks
        if (p.textContent?.includes("Mail ID:") || p.classList.contains("whitespace-pre-line")) {
          p.style.textAlign = "center"
          p.style.whiteSpace = "pre-line"
          p.style.marginBottom = "5px"
          p.style.width = "100%"
        } else {
          p.style.textAlign = "justify"
          p.style.marginBottom = "10px"
        }
        p.style.lineHeight = "1.5"
      })

      // Ensure header text is properly centered
      const headers = contentClone.querySelectorAll("h1, h2")
      headers.forEach((h) => {
        h.style.textAlign = "center"
        h.style.marginBottom = "10px"
        h.style.width = "100%"
      })

      // Make table more compact
      const tables = contentClone.querySelectorAll("table")
      tables.forEach((table) => {
        table.style.borderCollapse = "collapse"
        table.style.width = "100%"
        table.style.tableLayout = "fixed"
        table.style.marginBottom = "15px"
        table.style.fontSize = "10px" // Smaller font for table
      })

      const cells = contentClone.querySelectorAll("th, td")
      cells.forEach((cell) => {
        cell.setAttribute(
          "style",
          "border: 1px solid #000; padding: 4px; word-wrap: break-word; vertical-align: middle; font-size: 10px;",
        )
      })

      // Make signature section more compact
      const signatureSection = contentClone.querySelector("#proprietorship-signature")
      if (signatureSection) {
        signatureSection.setAttribute("style", "margin-top: 10px; text-align: right;")

        const signatureParagraphs = signatureSection.querySelectorAll("p")
        signatureParagraphs.forEach((p) => {
          p.style.marginBottom = "2px"
          p.style.textAlign = "right"
        })
      }

      tempDiv.appendChild(contentClone)
      document.body.appendChild(tempDiv)

      // Render the entire content at once with high quality
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: "#ffffff",
      })

      document.body.removeChild(tempDiv)

      // Create PDF in portrait orientation to fit on one page
      const pdf = new jsPDF("p", "mm", "a4")
      const imgData = canvas.toDataURL("image/png")

      // Calculate dimensions to fit the page
      const pageWidth = 210 // A4 width in portrait in mm
      const pageHeight = 297 // A4 height in portrait in mm
      const margin = 10

      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      // Add the image to the PDF
      pdf.addImage(imgData, "PNG", margin, margin, imgWidth, imgHeight)

      pdf.save(`${data.businessName}-Proprietorship.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to render partners in the proprietorship table
  const renderPartners = () => {
    if (partnershipType === "single") {
      return (
        <>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">1.</td>
            <td className="border border-gray-300 p-3">{data.authorityName}</td>
            <td className="border border-gray-300 p-3">{data.homeAddress}</td>
            <td className="border border-gray-300 p-3">{data.contactNo}</td>
            <td className="border border-gray-300 p-3">Proprietorship</td>
            <td className="border border-gray-300 p-3">PAN CARD</td>
            <td className="border border-gray-300 p-3">N/A</td>
          </tr>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">2.</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
          </tr>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">3.</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
          </tr>
        </>
      )
    } else {
      // For multiple partners
      return (
        <>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">1.</td>
            <td className="border border-gray-300 p-3">{data.authorityName}</td>
            <td className="border border-gray-300 p-3">{data.homeAddress}</td>
            <td className="border border-gray-300 p-3">{data.contactNo}</td>
            <td className="border border-gray-300 p-3">Operator</td>
            <td className="border border-gray-300 p-3">PAN CARD</td>
            <td className="border border-gray-300 p-3">N/A</td>
          </tr>
          {data.partners &&
            data.partners.map((partner: any, index: number) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="border border-gray-300 p-3">{index + 2}.</td>
                <td className="border border-gray-300 p-3">{partner.name || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.address || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.contact || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.description || "Partner"}</td>
                <td className="border border-gray-300 p-3">{partner.idDetails || "PAN CARD"}</td>
                <td className="border border-gray-300 p-3">{partner.appointmentDate || "N/A"}</td>
              </tr>
            ))}
          {/* Add empty rows if needed */}
          {!data.partners ||
            (data.partners.length === 0 && (
              <>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3">2.</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3">3.</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                </tr>
              </>
            ))}
        </>
      )
    }
  }

  // Get the current document ID and file name based on active tab
  const getCurrentDocumentInfo = () => {
    switch (activeTab) {
      case "self-declaration":
        return { id: "self-declaration-print", fileName: `${data.businessName}-Self-Declaration` }
      case "kyc":
        return { id: "kyc-print", fileName: `${data.businessName}-KYC` }
      case "proprietorship":
        return { id: "proprietorship-print", fileName: `${data.businessName}-Proprietorship` }
      case "authority-letter":
        return { id: "authority-letter-print", fileName: `${data.businessName}-Authority-Letter` }
      case "blueprint":
        return { id: "blueprint-print", fileName: `${data.businessName}-Blueprint` }
      case "equipment":
        return { id: "equipment-print", fileName: `${data.businessName}-Equipment-List` }
      case "recall-plan":
        return { id: "recall-plan-print", fileName: `${data.businessName}-Recall-Plan` }
      case "form-ix":
        return { id: "form-ix-print", fileName: `${data.businessName}-Form-No-IX` }
      default:
        return { id: "self-declaration-print", fileName: `${data.businessName}-Document` }
    }
  }

  // Function to render blueprint sections based on configuration
  const renderBlueprintSections = () => {
    // Check if we have positioned sections
    if (data.blueprintSectionsWithPositions && data.blueprintSectionsWithPositions.length > 0) {
      return (
        <div className="relative" style={{ height: "500px" }}>
          {data.blueprintImage && (
            <img
              src={data.blueprintImage || "/placeholder.svg"}
              alt="Blueprint Background"
              className="w-full h-full object-contain absolute top-0 left-0"
              style={{ opacity: 0.7 }}
            />
          )}

          {data.blueprintSectionsWithPositions.map((section) => (
            <div
              key={section.id}
              className="absolute bg-white border-2 border-blue-500 rounded p-2 shadow-md"
              style={{
                left: `${section.position.x}px`,
                top: `${section.position.y}px`,
                minWidth: "120px",
              }}
            >
              <div className="font-medium text-sm">{section.name}</div>
              {section.dimensions && <div className="text-xs text-gray-600">{section.dimensions}</div>}
            </div>
          ))}
        </div>
      )
    }

    // Use the blueprint configuration if available, otherwise use default order
    const sections = data.blueprintConfig?.sections || [
      { id: "rawMaterial", name: "Raw Material Storage Area", enabled: true, expanded: true, order: 0 },
      { id: "production", name: "Production Area", enabled: true, expanded: true, order: 1 },
      { id: "finishedGoods", name: "Finished Goods Storage Area", enabled: true, expanded: true, order: 2 },
      { id: "packing", name: "Packing and Dispatch Area", enabled: true, expanded: true, order: 3 },
      { id: "admin", name: "Admin Office/Cabin", enabled: true, expanded: true, order: 4 },
    ]

    // Sort sections by order
    const sortedSections = [...sections].sort((a, b) => a.order - b.order)

    // Filter enabled sections
    const enabledSections = sortedSections.filter((section) => section.enabled)

    return (
      <div className="grid grid-cols-1 gap-4">
        {enabledSections.map((section) => {
          const isExpanded =
            expandedSections[section.id] !== undefined ? expandedSections[section.id] : section.expanded

          return (
            <div key={section.id} className="border border-gray-300 p-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-bold">{section.name}</h3>
                <Button type="button" variant="ghost" size="sm" onClick={() => toggleSectionExpanded(section.id)}>
                  {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                </Button>
              </div>

              {isExpanded && (
                <div>
                  {section.id === "rawMaterial" && data.rawMaterialArea && (
                    <div className="min-h-[100px] flex flex-col justify-center items-center text-center">
                      <p>{data.rawMaterialArea}</p>
                    </div>
                  )}

                  {section.id === "production" && data.productionArea && (
                    <div className="min-h-[100px] flex flex-col justify-start items-center">
                      <p className="text-center mb-2">{data.productionArea}</p>
                      <div className="text-sm text-left w-full">
                        {data.equipmentList && data.equipmentList.length > 0 && (
                          <ul className="list-decimal pl-5">
                            {data.equipmentList.map((item, index) => (
                              <li key={index}>
                                {item.name} - {item.capacity}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>
                  )}

                  {section.id === "finishedGoods" && data.finishedGoodsArea && (
                    <div className="min-h-[100px] flex flex-col justify-center items-center text-center">
                      <p>{data.finishedGoodsArea}</p>
                    </div>
                  )}

                  {section.id === "packing" && data.packingArea && (
                    <div className="min-h-[100px] flex flex-col justify-center items-center text-center">
                      <p>{data.packingArea}</p>
                    </div>
                  )}

                  {section.id === "admin" && data.adminArea && (
                    <div className="min-h-[100px] flex flex-col justify-center items-center text-center">
                      <p>{data.adminArea}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Form
        </Button>
        <h2 className="text-2xl font-bold">Document Preview</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="self-declaration">Self Declaration</TabsTrigger>
          <TabsTrigger value="kyc">KYC</TabsTrigger>
          <TabsTrigger value="proprietorship">Proprietorship List</TabsTrigger>
          <TabsTrigger value="authority-letter">Authority Letter</TabsTrigger>
          {isManufacturing && <TabsTrigger value="blueprint">Blueprint</TabsTrigger>}
          {isManufacturing && <TabsTrigger value="equipment">Equipment List</TabsTrigger>}
          {isManufacturing && <TabsTrigger value="recall-plan">Recall Plan</TabsTrigger>}
          {isManufacturing && <TabsTrigger value="form-ix">Form No. IX</TabsTrigger>}
        </TabsList>

        <TabsContent value="self-declaration">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const { id, fileName } = getCurrentDocumentInfo()
                    handleDownload(id, fileName)
                  }}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="self-declaration-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-6">Self-Declaration for Proprietorship</h2>

                <p className="mb-4 text-justify">
                  I, {data.authorityName} S/O {data.authorityFatherName} R/O {data.homeAddress}, Do hereby state and
                  affirm as follows: -
                </p>

                <p className="mb-4 text-justify">
                  I am the sole proprietor of a business operating under the name and style "{data.businessName}"
                  Operating from {data.placeAddress}.
                </p>

                <p className="mb-4 text-justify">
                  This business is not undertaken/ operated by a partnership firm or limited liability company.
                </p>

                <p className="mb-4 text-justify">
                  It is also to declare that below mentioned person is my legal nominee for the said proprietorship
                  concern-
                </p>

                <p className="mb-4 text-justify">
                  Name: {data.nomineeName}
                  <br />
                  Relationship with the proprietor: {data.nomineeRelation}
                </p>

                <p className="mb-4 text-justify">
                  That the contents of this declaration are true and correct to the best of my knowledge and belief.
                </p>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Name: {data.authorityName}</p>
                  <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                  <p>Address: {data.homeAddress}</p>
                  <p>Date: {formatDate(data.date)}</p>
                  <p>Contact No: {data.contactNo}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kyc">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={handleKycDownload}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              {/* Hidden elements for PDF generation */}
              {data.aadhaarFrontImage && (
                <div className="hidden" id="aadhaar-front-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.aadhaarFrontImage || "/placeholder.svg"}
                        alt="Aadhaar Card Front"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              {data.aadhaarBackImage && (
                <div className="hidden" id="aadhaar-back-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.aadhaarBackImage || "/placeholder.svg"}
                        alt="Aadhaar Card Back"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              {data.panImage && (
                <div className="hidden" id="pan-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.panImage || "/placeholder.svg"}
                        alt="PAN Card"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="kyc-info-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                  KYC Document
                </h2>

                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Name:</div>
                    <div className="col-span-2">{data.businessName}</div>
                  </div>

                  {data.gstin && (
                    <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                      <div className="font-semibold text-gray-700">GSTIN:</div>
                      <div className="col-span-2">{data.gstin}</div>
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Address:</div>
                    <div className="col-span-2">{data.placeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Name:</div>
                    <div className="col-span-2">{data.authorityName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Father's Name:</div>
                    <div className="col-span-2">{data.authorityFatherName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Home Address:</div>
                    <div className="col-span-2">{data.homeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Contact Number:</div>
                    <div className="col-span-2">{data.contactNo}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Email:</div>
                    <div className="col-span-2">{data.email}</div>
                  </div>

                  {isManufacturing && data.productType && data.manufacturingCapacity && (
                    <>
                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Product Type:</div>
                        <div className="col-span-2">{data.productType}</div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Manufacturing Capacity:</div>
                        <div className="col-span-2">{data.manufacturingCapacity}</div>
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Name:</div>
                    <div className="col-span-2">{data.nomineeName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Relation:</div>
                    <div className="col-span-2">{data.nomineeRelation}</div>
                  </div>
                </div>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Date: {formatDate(data.date)}</p>
                </div>
              </div>

              {/* Visible KYC document with all images */}
              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="kyc-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-6">KYC Document</h2>

                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Name:</div>
                    <div className="col-span-2">{data.businessName}</div>
                  </div>

                  {data.gstin && (
                    <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                      <div className="font-semibold text-gray-700">GSTIN:</div>
                      <div className="col-span-2">{data.gstin}</div>
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Address:</div>
                    <div className="col-span-2">{data.placeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Name:</div>
                    <div className="col-span-2">{data.authorityName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Father's Name:</div>
                    <div className="col-span-2">{data.authorityFatherName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Home Address:</div>
                    <div className="col-span-2">{data.homeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Contact Number:</div>
                    <div className="col-span-2">{data.contactNo}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Email:</div>
                    <div className="col-span-2">{data.email}</div>
                  </div>

                  {isManufacturing && data.productType && data.manufacturingCapacity && (
                    <>
                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Product Type:</div>
                        <div className="col-span-2">{data.productType}</div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Manufacturing Capacity:</div>
                        <div className="col-span-2">{data.manufacturingCapacity}</div>
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Name:</div>
                    <div className="col-span-2">{data.nomineeName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Relation:</div>
                    <div className="col-span-2">{data.nomineeRelation}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">Aadhaar Card (Front):</div>
                    <div className="col-span-2">
                      {data.aadhaarFrontImage ? (
                        <img
                          src={data.aadhaarFrontImage || "/placeholder.svg"}
                          alt="Aadhaar Card Front"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">Aadhaar Card (Back):</div>
                    <div className="col-span-2">
                      {data.aadhaarBackImage ? (
                        <img
                          src={data.aadhaarBackImage || "/placeholder.svg"}
                          alt="Aadhaar Card Back"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">PAN Card:</div>
                    <div className="col-span-2">
                      {data.panImage ? (
                        <img
                          src={data.panImage || "/placeholder.svg"}
                          alt="PAN Card"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Date: {formatDate(data.date)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="proprietorship">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={generateCompleteProprietorshipPDF}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="proprietorship-print"
              >
                <div id="proprietorship-content">
                  <div id="proprietorship-header" className="text-center mb-8">
                    <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                    {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                    <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                    <p className="text-sm text-center w-full">
                      Mail ID: {data.email} | Mo Number: {data.contactNo}
                    </p>
                    <h2 className="text-lg font-bold text-center mt-6 mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                      Proprietorship
                    </h2>
                  </div>

                  <div id="proprietorship-table" className="overflow-x-auto mb-8">
                    <table className="w-full border-collapse border border-gray-300" style={{ tableLayout: "fixed" }}>
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "8%" }}>
                            Sl.no
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "18%" }}>
                            Name of the partners*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "18%" }}>
                            Address
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Contact no.*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Description*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            ID Details*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Date of appointment
                          </th>
                        </tr>
                      </thead>
                      <tbody>{renderPartners()}</tbody>
                    </table>
                  </div>

                  <div id="proprietorship-signature" className="mt-8 text-right">
                    <p className="mb-1 text-right">Signature of the authorized signatory</p>
                    <p className="text-right">(Along with seal of Proprietorship firm)</p>

                    <div className="flex justify-end items-center gap-4 mb-4">
                      {data.stampImage && (
                        <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                          <img
                            src={data.stampImage || "/placeholder.svg"}
                            alt="Proprietor Stamp"
                            className="h-20 object-contain"
                          />
                        </div>
                      )}
                      {data.signatureImage && (
                        <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                          <img
                            src={data.signatureImage || "/placeholder.svg"}
                            alt="Proprietor Signature"
                            className="h-20 object-contain"
                          />
                        </div>
                      )}
                      {!data.stampImage && !data.signatureImage && (
                        <div className="h-16 border-b border-dashed w-32"></div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="authority-letter">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const { id, fileName } = getCurrentDocumentInfo()
                    handleDownload(id, fileName)
                  }}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">Owner Name (for NOC)</label>
                <Input
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="Enter property owner's name"
                  className="max-w-md"
                />
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="authority-letter-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-center mt-6 mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                    No Objection Certificate
                  </h2>
                </div>

                <div className="w-full text-center mb-8 concern-text">
                  <p className="font-semibold text-xl text-center w-full inline-block">TO WHOMSOEVER IT MAY CONCERN</p>
                </div>

                <p className="mb-4 text-justify">
                  This is to certify that I {ownerName} S/O {data.authorityFatherName} (Name of the owner), owner of the
                  property, {data.placeAddress} (Principal address)
                </p>

                <p className="mb-4 text-justify">
                  Further I have permitted {data.businessName}, represented by {data.authorityName} (Proprietor), to use
                  the above-mentioned property for business purpose. It is hereby solemnly affirmed that I have no
                  objection in the above property being used for the business purposes.
                </p>

                <p className="mb-4 text-justify">
                  This no objection certificate is issued for the purposes of obtaining any registrations as per the
                  local tax laws
                </p>

                <div className="mt-8 grid grid-cols-2 gap-8">
                  <div>
                    <p className="mb-1">Owner of the property</p>
                    <div className="h-16 border-b border-dashed w-full mb-4"></div>
                    <p>Signature</p>
                    <p>{ownerName}</p>
                  </div>

                  <div>
                    <p className="mb-1">Proprietor</p>
                    <div className="h-16 border-b border-dashed w-full mb-4"></div>
                    <p>Signature</p>
                    <p>{data.authorityName}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blueprint">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleDownload("blueprint-print", `${data.businessName}-Blueprint`)}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="blueprint-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-xl font-bold text-center mb-6 border-b-2 border-gray-300 pb-2 inline-block">
                  BLUEPRINT LAYOUT
                </h2>

                {data.facilityDimensions && (
                  <p className="text-center mb-6">Total Dimensions: {data.facilityDimensions}</p>
                )}

                <div className="border-2 border-gray-300 p-4 mb-8">
                  {data.blueprintImage ? (
                    <div className="relative">
                      <img
                        src={data.blueprintImage || "/placeholder.svg"}
                        alt="Facility Blueprint"
                        className="w-full object-contain"
                      />
                      {renderBlueprintSections()}
                    </div>
                  ) : (
                    renderBlueprintSections()
                  )}
                </div>

                <div className="mt-6">
                  <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                  <p>Date: {formatDate(data.date)}</p>
                </div>

                <div className="mt-4">
                  <p className="font-semibold">For {data.businessName}</p>

                  <div className="mt-4 flex items-center gap-4">
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Authorized Signatory"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.signatureImage && <div className="h-16 border-b border-dashed w-48"></div>}
                  </div>

                  <p className="mt-2">1. Authorized signatory of the company</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="equipment">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleDownload("equipment-print", `${data.businessName}-Equipment-List`)}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="equipment-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-xl font-bold text-center mb-6 border-b-2 border-gray-300 pb-2 inline-block">
                  Name and List of Equipment and Machinery
                </h2>

                <div className="overflow-x-auto mb-8">
                  <table className="w-full border-collapse border border-gray-300 table-fixed">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="border border-gray-300 p-3 text-left font-semibold">Sl no.</th>
                        <th className="border border-gray-300 p-3 text-left font-semibold">Image</th>
                        <th className="border border-gray-300 p-3 text-left font-semibold">Equipment/Machinery</th>
                        <th className="border border-gray-300 p-3 text-left font-semibold">Power Load</th>
                        <th className="border border-gray-300 p-3 text-left font-semibold">
                          No. of Equipment/Machinery
                        </th>
                        <th className="border border-gray-300 p-3 text-left font-semibold">Installed Capacity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.equipmentList && data.equipmentList.length > 0 ? (
                        data.equipmentList.map((item, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="border border-gray-300 p-3">{index + 1}.</td>
                            <td className="border border-gray-300 p-3 text-center">
                              {item.image && item.image !== "" ? (
                                <img
                                  src={item.image || "/placeholder.svg"}
                                  alt={`${item.name} Image`}
                                  className="h-24 object-contain mx-auto"
                                />
                              ) : (
                                "-"
                              )}
                            </td>
                            <td className="border border-gray-300 p-3">{item.name || "-"}</td>
                            <td className="border border-gray-300 p-3">{item.powerLoad || "-"}</td>
                            <td className="border border-gray-300 p-3">{item.quantity || "-"}</td>
                            <td className="border border-gray-300 p-3">{item.capacity || "-"}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="border border-gray-300 p-3 text-center">
                            No equipment data available
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="mt-8">
                  <p className="mb-1">
                    • Power, Load and Voltage is not compulsory but other than that the remaining details needs to be
                    submitted.
                  </p>

                  <div className="mt-6">
                    <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                    <p>Date: {formatDate(data.date)}</p>
                  </div>

                  <div className="mt-4">
                    <p className="font-semibold">For {data.businessName}</p>

                    <div className="mt-4 flex items-center gap-4">
                      {data.signatureImage && (
                        <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                          <img
                            src={data.signatureImage || "/placeholder.svg"}
                            alt="Authorized Signatory"
                            className="h-20 object-contain"
                          />
                        </div>
                      )}
                      {!data.signatureImage && <div className="h-16 border-b border-dashed w-48"></div>}
                    </div>

                    <p className="mt-2">1. Authorized signatory of the company</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="recall-plan">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleDownload("recall-plan-print", `${data.businessName}-Recall-Plan`)}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="recall-plan-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold">Annexure-I</h2>
                  <h3 className="text-lg font-bold mt-2">({data.businessName}) Recall Plan</h3>
                </div>

                <div className="space-y-4 text-justify">
                  <p>
                    In the event that if any of our products, that presents a threat to the public health or food that
                    violate the Act and Rules and Regulations made there under {data.businessName} will protect public
                    health by facilitating the efficient, rapid identification and removal of unsafe food from the
                    distribution chain and, by informing consumers of the presence in the market of such food.
                  </p>

                  <p>
                    There is a documented recall procedure in place and this will be periodically tested to ensure that
                    it is comprehensive and fit for purpose in its ability to remove an unsafe food from consumers
                    and/or the distribution chain.
                  </p>

                  <h3 className="text-lg font-bold mt-6">Recall Procedure</h3>
                  <h4 className="text-md font-bold">Introduction</h4>

                  <p>
                    This procedure states the action/s {data.businessName} will take to effectively manage the food
                    recall in case the food does not meet the requirements of the hygiene, safety and quality of food as
                    well as protect the health of consumers.
                  </p>

                  <p>
                    An effective product recall will ensure that the unsafe or food that violate the Act and Rules and
                    Regulations made there under is contained and either destroyed or rendered safe.
                  </p>

                  <p>
                    We will refer to and follow instructions when required which are laid out in the following
                    documents:
                  </p>

                  <ul className="list-disc pl-6 space-y-1">
                    <li>Food Safety and Standards (Food Recall Procedures) regulation, 2017</li>
                    <li>FSSAI Website (www.fssai.gov.in)</li>
                    <li>Guidelines for food recall plan</li>
                  </ul>

                  <h4 className="text-md font-bold mt-4">Roles and Responsibilities</h4>

                  <p>
                    It is our ({data.businessName}) responsibility to effectively organize and manage the recall of food
                    that presents a threat to the public health or food that violate the Act and Rules and Regulations
                    made there under and to formulate a broad level recall plan as per FSSAI guideline on recall plan.
                  </p>

                  <p>
                    The recall co-ordinator for the site is ({data.authorityName}) who has been given authority from
                    management to make recall decisions on behalf of ({data.businessName}) is initiated, our actions in
                    recalling the affected food/s need to be co-ordinated with the When a recall concerned Authority.
                  </p>

                  <p>
                    We shall notify concerned Authority likely to be initiated. It is our responsibility to manage the
                    recall by clarifying the food safety as soon as a recall is issue and the exposure (who and where
                    risk exists), and to provide details on distribution and the method of recall.
                  </p>

                  <h4 className="text-md font-bold mt-4">The Recall management team</h4>

                  <p>
                    The recall co-ordinator ({data.authorityName}) will initiate the formation of a recall management
                    and our marketing and distribution agents. Committee members will include personnel from across our
                    ({data.businessName}) typically the committee would be like
                  </p>

                  <h3 className="text-lg font-bold text-center mt-6">({data.businessName}) RECALL PLAN</h3>

                  <div className="space-y-2 mt-4">
                    <p>
                      <span className="font-semibold">Company name:</span> {data.businessName}
                    </p>
                    <p>
                      <span className="font-semibold">Address:</span> {data.placeAddress}
                    </p>
                    <p>
                      <span className="font-semibold">Phone No:</span> {data.contactNo}
                    </p>
                    <p>
                      <span className="font-semibold">Products produced:</span> {data.productType}
                    </p>
                  </div>

                  <h4 className="text-md font-bold text-center mt-6">RECALL MANAGEMENT TEAM</h4>

                  <div className="overflow-x-auto mt-4">
                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border border-gray-300 p-2">NAME</th>
                          <th className="border border-gray-300 p-2">ALTERNATE PERSON</th>
                          <th className="border border-gray-300 p-2">BUSINESS PHONE</th>
                          <th className="border border-gray-300 p-2">AFTER HOURS PHONE</th>
                          <th className="border border-gray-300 p-2">HOURS</th>
                          <th className="border border-gray-300 p-2">RESPONSIBILITIES DURING RECALL</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-gray-300 p-2">{data.authorityName}</td>
                          <td className="border border-gray-300 p-2">{data.nomineeName}</td>
                          <td className="border border-gray-300 p-2">{data.contactNo}</td>
                          <td className="border border-gray-300 p-2">{data.contactNo}</td>
                          <td className="border border-gray-300 p-2">9:00 AM to 6:00 PM</td>
                          <td className="border border-gray-300 p-2">Communicating with customers, suppliers</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <p className="mt-4">
                    The recall management team is responsible for the management of all recall activities and to adhere
                    to this procedure. Duties of the recall management team are to:
                  </p>

                  <ul className="list-disc pl-6 space-y-1">
                    <li>assess the overall problem;</li>
                    <li>notify the relevant regulatory authority;</li>
                    <li>evaluate the hazard in the food and the extent of contamination;</li>
                    <li>determine a strategy to be followed;</li>
                    <li>make decisions about product still in manufacture or in storage;</li>
                    <li>notify insurers.</li>
                  </ul>

                  <h4 className="text-md font-bold mt-6">Recall Actions & Documentation</h4>

                  <p>
                    The recall management team shall reference and follow the actions outlined in the Safety and
                    Standards (Food Recall Procedures) regulation, 2017 when we become aware a product may be unsafe or
                    food that violate the Act and Rules and Regulations made there under. We will ensure that records of
                    all actions and decisions and who was responsible are recorded and retained.
                  </p>

                  <h4 className="text-md font-bold mt-4">Decision to Recall</h4>

                  <p>The decision to recall will be submitted to Food Safety and Standards Authority of India</p>

                  <h4 className="text-md font-bold mt-4">Notification of a product recall</h4>

                  <p>If the decision is taken to initiate a recall, we will notify:</p>

                  <ul className="list-disc pl-6 space-y-1">
                    <li>Senior management of ({data.businessName}), supply chain personnel Food Authority.</li>
                    <li>Food Authority</li>
                    <li>
                      Anyone that has received our product, including distributors, wholesalers, retailers and caterers.
                    </li>
                    <li>Consumers, via the media contacts included on our contact list.</li>
                  </ul>

                  <p className="mt-4">The contact list must contain the contact details for the following:</p>

                  <ul className="list-disc pl-6 space-y-1">
                    <li>The products recall committee and senior management and key company personnel.</li>
                    <li>Suppliers of all ingredients.</li>
                    <li>Downstream Food Business Operator and business customers.</li>
                    <li>
                      Sources of technical advice and support including laboratory facilities. Regulatory Authorities.
                    </li>
                    <li>Regulatory Authorities</li>
                  </ul>

                  <h4 className="text-md font-bold mt-6">Regaining control of affected stock</h4>

                  <p>
                    The recovered product/s will be stored in an area that is separated from any other food products.
                    Accurate records will be kept of the amounts recovered and the codes of the product/s. If the
                    recovered product/s is unfit for human consumption, it may be destroyed or denatured under the
                    supervision of the company management and/or the regulatory authority where legally required. If the
                    food safety risk can be safely removed from the recovered product/s through relabeling or
                    reprocessing this may be done once it is clear that public health will be protected.
                  </p>

                  <h4 className="text-md font-bold mt-4">Recall Status report</h4>

                  <p>
                    Periodic status reports will be submitted to the CEO, FSSAI after the notification of the recall for
                    assessing the progress of the recall. The frequency of such reports will be determined by the
                    relative urgency/gravity of the recall and will be specified by the concerned food authority for
                    each recall. However, in any case the reporting interval shall not be more than 1 week. The recall
                    status report should contain information specified under Schedule II of Food Safety and Standards
                    (Food Recall Procedure) Regulations, 2017.
                  </p>

                  <h4 className="text-md font-bold mt-4">Post recall report</h4>

                  <p>
                    Recall management team will submit post recall report to the CEO, FSSAI after the completion of the
                    recall to assess the effectiveness of the recall. In addition ({data.businessName}) will investigate
                    the reasons that led to such recall and will take action to prevent recurrence of the problem.
                  </p>

                  <h4 className="text-md font-bold mt-4">Termination of a recall</h4>

                  <p>
                    ({data.businessName}) may request termination of the recall by submitting a written request to the
                    CEO, FSSAI along with the latest recall status report stating that the recall was effective.
                  </p>

                  <p>
                    The recall will be terminated when the concerned food authority determines that all reasonable
                    efforts have been made in accordance with the recall strategy and it is reasonable to assume that
                    the food product subject to the recall has been removed and proper disposition or correction has
                    been made, commensurate with the degree of hazard of the recalled food product. Written notification
                    that a recall is terminated will be issued by the Food authority to the company.
                  </p>

                  <p>
                    In case of unsatisfactory reports, the concerned food authority may consider further action like
                    stepped-up inspection, seizure or any other legal action, against ({data.businessName})
                  </p>

                  <h4 className="text-md font-bold mt-4">Follow up action</h4>

                  <p>
                    We ({data.businessName}) will submit an interim report as soon as recall is completed to the
                    regulatory authorities within an agreed timeframe of the closure of the recall in any case not later
                    than thirty days after the completion of a recall. The final report will include the elements
                    outlined in the FSS (Food Recall Procedure) Regulations, 2017.
                  </p>
                </div>

                <div className="mt-12">
                  <div className="text-center">
                    <div className="flex justify-between mb-8">
                      <div>
                        <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                        <p>Date: {formatDate(data.date)}</p>
                      </div>
                      <div></div>
                    </div>
                    <p className="mb-4">For {data.businessName}</p>
                    {data.signatureImage ? (
                      <div className="flex justify-center mb-2">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Authorized Signatory"
                          className="h-16 object-contain"
                        />
                      </div>
                    ) : (
                      <div className="h-16 border-b border-dashed w-48 mx-auto mb-2"></div>
                    )}
                    <p>1. Authorized signatory of the company</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="form-ix">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleDownload("form-ix-print", `${data.businessName}-Form-No-IX`)}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="form-ix-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  {data.gstin && <p className="text-sm font-medium mb-2 text-center">GSTIN-{data.gstin}</p>}
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-xl font-bold">FORM NO.IX</h2>
                  <p className="mt-2">(Form of Nomination – Refer rule 2.5.1)</p>
                  <h3 className="text-lg font-bold mt-4">NOMINATION OF PERSONS BY A COMPANY</h3>
                </div>

                <div className="space-y-4 text-justify">
                  <p>
                    Being the proprietor or a signatory authorized by the board of directors of the company in terms of
                    Rule 2.5.1 (2), I do hereby gives notice that the following persons(s) is/are nominated as the
                    person(s) in charge of establishment, branch or the unit mentioned against the name of the person(s)
                    and shall be responsible and liable for food safety or any contravention of the Act and
                    rules/regulations or directions issued there under in respect of the concerned
                    establishment/branch/unit. The person(s) shall take all such steps as may be necessary to prevent
                    the commission by the Company of any offence under and comply with the provisions of Food Safety and
                    Standards Act, 2006 and the Rules and Regulations made there under.
                  </p>

                  <h4 className="text-md font-bold mt-6">Branch wise/office wise nomination</h4>

                  <div className="overflow-x-auto mt-4">
                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border border-gray-300 p-3 text-left font-semibold">
                            Establishment/branch/unit name
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold">
                            Name and Sign of Person i/c
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-gray-300 p-3">
                            {data.businessName}
                            <br />
                            {data.placeAddress}
                          </td>
                          <td className="border border-gray-300 p-3">
                            <div>
                              <p>1. {data.authorityName}</p>
                              {data.signatureImage && (
                                <div className="mt-2">
                                  <img
                                    src={data.signatureImage || "/placeholder.svg"}
                                    alt="Authorized Signatory"
                                    className="h-12 object-contain"
                                  />
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <p className="mt-6">
                    A certified copy of the resolution of the board regarding the authorized
                    <br />
                    Signatory, enclosed.
                  </p>
                </div>

                <div className="mt-12">
                  <div className="text-center">
                    <div className="flex justify-between mb-8">
                      <div>
                        <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                        <p>Date: {formatDate(data.date)}</p>
                      </div>
                      <div></div>
                    </div>
                    <p className="mb-4">For {data.businessName}</p>
                    {data.signatureImage ? (
                      <div className="flex justify-center mb-2">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Authorized Signatory"
                          className="h-16 object-contain"
                        />
                      </div>
                    ) : (
                      <div className="h-16 border-b border-dashed w-48 mx-auto mb-2"></div>
                    )}
                    <p>1. Authorized signatory of the company</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
