"use client"

import { useState } from "react"
import { format } from "date-fns"
import { ArrowLeft, Download, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { Input } from "@/components/ui/input"

// Define proper types for the component props
interface DocumentPreviewProps {
  data: any
  onBack: () => void
  isManufacturing?: boolean
  partnershipType?: "single" | "multiple"
}

export default function DocumentPreview({
  data,
  onBack,
  isManufacturing = false,
  partnershipType = "single",
}: DocumentPreviewProps) {
  const [activeTab, setActiveTab] = useState("self-declaration")
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const [ownerName, setOwnerName] = useState<string>(data?.authorityName || "")

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return ""
    return format(new Date(date), "dd/MM/yyyy")
  }

  // If data is null, show a loading state or error message
  if (!data) {
    return (
      <div className="flex justify-center items-center h-64">
        <p>No data available. Please go back and fill the form.</p>
        <Button variant="outline" onClick={onBack} className="ml-4">
          Back to Form
        </Button>
      </div>
    )
  }

  // Function to handle printing
  const handlePrint = () => {
    window.print()
  }

  // Function to handle PDF download for KYC with multiple pages
  const handleKycDownload = async () => {
    setIsGeneratingPdf(true)

    try {
      const pdf = new jsPDF("p", "mm", "a4")
      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm

      // Generate Aadhaar Front Page - Full page image only
      if (data.aadhaarFrontImage) {
        // Create a temporary div with just the image
        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.aadhaarFrontImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate Aadhaar Back Page - Full page image only
      if (data.aadhaarBackImage) {
        pdf.addPage()

        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.aadhaarBackImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate PAN Card Page - Full page image only
      if (data.panImage) {
        pdf.addPage()

        const tempDiv = document.createElement("div")
        tempDiv.style.width = "100%"
        tempDiv.style.height = "100%"
        tempDiv.style.display = "flex"
        tempDiv.style.justifyContent = "center"
        tempDiv.style.alignItems = "center"
        tempDiv.style.backgroundColor = "#ffffff"
        tempDiv.style.padding = "10px"

        const img = document.createElement("img")
        img.src = data.panImage
        img.style.maxWidth = "100%"
        img.style.maxHeight = "100%"
        img.style.objectFit = "contain"

        tempDiv.appendChild(img)
        document.body.appendChild(tempDiv)

        const canvas = await html2canvas(tempDiv, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        document.body.removeChild(tempDiv)

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        // Calculate positioning to center the image on the page
        const yPosition = Math.max(0, (pageHeight - imgHeight) / 2)
        pdf.addImage(imgData, "PNG", 0, yPosition, imgWidth, imgHeight)
      }

      // Generate KYC Info Page
      pdf.addPage()
      const kycInfoElement = document.getElementById("kyc-info-print")
      if (kycInfoElement) {
        const canvas = await html2canvas(kycInfoElement, {
          scale: 4,
          useCORS: true,
          allowTaint: true,
          logging: false,
          backgroundColor: "#ffffff",
        })

        const imgData = canvas.toDataURL("image/png")
        const imgHeight = (canvas.height * imgWidth) / canvas.width

        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight)
      }

      // Add page numbers to KYC PDF
      const totalPages = pdf.getNumberOfPages()
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i)
        pdf.setFontSize(10)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Page ${i} of ${totalPages}`, imgWidth - 30, pageHeight - 10)
      }

      pdf.save(`${data.businessName}-KYC-Documents.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to handle PDF download for regular documents
  const handleDownload = async (elementId: string, fileName: string) => {
    setIsGeneratingPdf(true)

    try {
      const element = document.getElementById(elementId)
      if (!element) {
        console.error(`Element with ID ${elementId} not found`)
        return
      }

      // Clone the element to apply formatting without affecting the original
      const tempDiv = document.createElement("div")
      tempDiv.style.width = "800px" // Set a fixed width for better quality
      tempDiv.style.padding = "30px"
      tempDiv.style.backgroundColor = "#ffffff"
      tempDiv.style.fontFamily = "Arial, sans-serif"

      // Clone the content
      const contentClone = element.cloneNode(true) as HTMLElement

      // Apply additional styling for better formatting
      const paragraphs = contentClone.querySelectorAll("p")
      paragraphs.forEach((p) => {
        if (p.textContent?.includes("Mail ID:") || p.classList.contains("whitespace-pre-line")) {
          p.style.textAlign = "center"
          p.style.width = "100%"
        } else if (p.classList.contains("font-semibold") && p.textContent?.includes("TO WHOMSOEVER")) {
          p.style.textAlign = "center"
          p.style.width = "100%"
          p.style.display = "block"
          p.style.marginLeft = "auto"
          p.style.marginRight = "auto"
        } else {
          p.style.textAlign = "justify"
        }
        p.style.marginBottom = "10px"
        p.style.lineHeight = "1.5"
      })

      // Ensure headers are centered
      const headers = contentClone.querySelectorAll("h1, h2")
      headers.forEach((h) => {
        h.style.textAlign = "center"
        h.style.width = "100%"
      })

      // Ensure the TO WHOMSOEVER IT MAY CONCERN is centered
      const concernDiv = contentClone.querySelector(".concern-text")
      if (concernDiv) {
        concernDiv.setAttribute("style", "text-align: center; width: 100%; margin: 0 auto;")
      }

      tempDiv.appendChild(contentClone)
      document.body.appendChild(tempDiv)

      const canvas = await html2canvas(tempDiv, {
        scale: 4,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: "#ffffff",
      })

      document.body.removeChild(tempDiv)

      const imgData = canvas.toDataURL("image/png")

      // Calculate dimensions to maintain aspect ratio
      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      const pdf = new jsPDF("p", "mm", "a4")

      let heightLeft = imgHeight
      let position = 0

      // Add first page
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      // Add additional pages if needed
      let pageCount = 1
      while (heightLeft > 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pageCount++
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      // Add page numbers
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i)
        pdf.setFontSize(10)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Page ${i} of ${pageCount}`, imgWidth - 30, pageHeight - 10)
      }

      pdf.save(`${fileName}.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to generate a complete proprietorship document as a single image
  const generateCompleteProprietorshipPDF = async () => {
    setIsGeneratingPdf(true)

    try {
      // Get the entire proprietorship content
      const element = document.getElementById("proprietorship-print")
      if (!element) {
        console.error("Proprietorship element not found")
        return
      }

      // Create a temporary div to hold the content for rendering
      const tempDiv = document.createElement("div")
      tempDiv.style.width = "800px" // Reduced width for better fit on one page
      tempDiv.style.padding = "20px"
      tempDiv.style.backgroundColor = "#ffffff"
      tempDiv.style.fontFamily = "Arial, sans-serif"

      // Clone the content to avoid modifying the original
      const contentClone = element.cloneNode(true) as HTMLElement

      // Apply additional styling to ensure proper formatting
      const paragraphs = contentClone.querySelectorAll("p")
      paragraphs.forEach((p) => {
        // For address and contact info in the header, preserve line breaks
        if (p.textContent?.includes("Mail ID:") || p.classList.contains("whitespace-pre-line")) {
          p.style.textAlign = "center"
          p.style.whiteSpace = "pre-line"
          p.style.marginBottom = "5px"
          p.style.width = "100%"
        } else {
          p.style.textAlign = "justify"
          p.style.marginBottom = "10px"
        }
        p.style.lineHeight = "1.5"
      })

      // Ensure header text is properly centered
      const headers = contentClone.querySelectorAll("h1, h2")
      headers.forEach((h) => {
        h.style.textAlign = "center"
        h.style.marginBottom = "10px"
        h.style.width = "100%"
      })

      // Make table more compact
      const tables = contentClone.querySelectorAll("table")
      tables.forEach((table) => {
        table.style.borderCollapse = "collapse"
        table.style.width = "100%"
        table.style.tableLayout = "fixed"
        table.style.marginBottom = "15px"
        table.style.fontSize = "10px" // Smaller font for table
      })

      const cells = contentClone.querySelectorAll("th, td")
      cells.forEach((cell) => {
        cell.setAttribute(
          "style",
          "border: 1px solid #000; padding: 4px; word-wrap: break-word; vertical-align: middle; font-size: 10px;",
        )
      })

      // Make signature section more compact
      const signatureSection = contentClone.querySelector("#proprietorship-signature")
      if (signatureSection) {
        signatureSection.setAttribute("style", "margin-top: 10px; text-align: right;")

        const signatureParagraphs = signatureSection.querySelectorAll("p")
        signatureParagraphs.forEach((p) => {
          p.style.marginBottom = "2px"
          p.style.textAlign = "right"
        })
      }

      tempDiv.appendChild(contentClone)
      document.body.appendChild(tempDiv)

      // Render the entire content at once with high quality
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: "#ffffff",
      })

      document.body.removeChild(tempDiv)

      // Create PDF in portrait orientation to fit on one page
      const pdf = new jsPDF("p", "mm", "a4")
      const imgData = canvas.toDataURL("image/png")

      // Calculate dimensions to fit the page
      const pageWidth = 210 // A4 width in portrait in mm
      const pageHeight = 297 // A4 height in portrait in mm
      const margin = 10

      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      // Add the image to the PDF
      pdf.addImage(imgData, "PNG", margin, margin, imgWidth, imgHeight)

      pdf.save(`${data.businessName}-Proprietorship.pdf`)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  // Function to render partners in the proprietorship table
  const renderPartners = () => {
    if (partnershipType === "single") {
      return (
        <>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">1.</td>
            <td className="border border-gray-300 p-3">{data.authorityName}</td>
            <td className="border border-gray-300 p-3">{data.homeAddress}</td>
            <td className="border border-gray-300 p-3">{data.contactNo}</td>
            <td className="border border-gray-300 p-3">Proprietorship</td>
            <td className="border border-gray-300 p-3">PAN CARD</td>
            <td className="border border-gray-300 p-3">N/A</td>
          </tr>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">2.</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
          </tr>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">3.</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
            <td className="border border-gray-300 p-3">&nbsp;</td>
          </tr>
        </>
      )
    } else {
      // For multiple partners
      return (
        <>
          <tr className="hover:bg-gray-50">
            <td className="border border-gray-300 p-3">1.</td>
            <td className="border border-gray-300 p-3">{data.authorityName}</td>
            <td className="border border-gray-300 p-3">{data.homeAddress}</td>
            <td className="border border-gray-300 p-3">{data.contactNo}</td>
            <td className="border border-gray-300 p-3">Operator</td>
            <td className="border border-gray-300 p-3">PAN CARD</td>
            <td className="border border-gray-300 p-3">N/A</td>
          </tr>
          {data.partners &&
            data.partners.map((partner: any, index: number) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="border border-gray-300 p-3">{index + 2}.</td>
                <td className="border border-gray-300 p-3">{partner.name || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.address || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.contact || "&nbsp;"}</td>
                <td className="border border-gray-300 p-3">{partner.description || "Partner"}</td>
                <td className="border border-gray-300 p-3">{partner.idDetails || "PAN CARD"}</td>
                <td className="border border-gray-300 p-3">{partner.appointmentDate || "N/A"}</td>
              </tr>
            ))}
          {/* Add empty rows if needed */}
          {!data.partners ||
            (data.partners.length === 0 && (
              <>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3">2.</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="border border-gray-300 p-3">3.</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                  <td className="border border-gray-300 p-3">&nbsp;</td>
                </tr>
              </>
            ))}
        </>
      )
    }
  }

  // Get the current document ID and file name based on active tab
  const getCurrentDocumentInfo = () => {
    switch (activeTab) {
      case "self-declaration":
        return { id: "self-declaration-print", fileName: `${data.businessName}-Self-Declaration` }
      case "kyc":
        return { id: "kyc-print", fileName: `${data.businessName}-KYC` }
      case "proprietorship":
        return { id: "proprietorship-print", fileName: `${data.businessName}-Proprietorship` }
      case "authority-letter":
        return { id: "authority-letter-print", fileName: `${data.businessName}-Authority-Letter` }
      default:
        return { id: "self-declaration-print", fileName: `${data.businessName}-Document` }
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Form
        </Button>
        <h2 className="text-2xl font-bold">Document Preview</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="self-declaration">Self Declaration</TabsTrigger>
          <TabsTrigger value="kyc">KYC</TabsTrigger>
          <TabsTrigger value="proprietorship">Proprietorship List</TabsTrigger>
          <TabsTrigger value="authority-letter">Authority Letter</TabsTrigger>
        </TabsList>

        <TabsContent value="self-declaration">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const { id, fileName } = getCurrentDocumentInfo()
                    handleDownload(id, fileName)
                  }}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="self-declaration-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-6">Self-Declaration for Proprietorship</h2>

                <p className="mb-4 text-justify">
                  I, {data.authorityName} S/O {data.authorityFatherName} R/O {data.homeAddress}, Do hereby state and
                  affirm as follows: -
                </p>

                <p className="mb-4 text-justify">
                  I am the sole proprietor of a business operating under the name and style "{data.businessName}"
                  Operating from {data.placeAddress}.
                </p>

                <p className="mb-4 text-justify">
                  This business is not undertaken/ operated by a partnership firm or limited liability company.
                </p>

                <p className="mb-4 text-justify">
                  It is also to declare that below mentioned person is my legal nominee for the said proprietorship
                  concern-
                </p>

                <p className="mb-4 text-justify">
                  Name: {data.nomineeName}
                  <br />
                  Relationship with the proprietor: {data.nomineeRelation}
                </p>

                <p className="mb-4 text-justify">
                  That the contents of this declaration are true and correct to the best of my knowledge and belief.
                </p>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Name: {data.authorityName}</p>
                  <p>Place: {data.placeAddress.split(",").pop()?.trim() || ""}</p>
                  <p>Address: {data.homeAddress}</p>
                  <p>Date: {formatDate(data.date)}</p>
                  <p>Contact No: {data.contactNo}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kyc">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={handleKycDownload}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              {/* Hidden elements for PDF generation */}
              {data.aadhaarFrontImage && (
                <div className="hidden" id="aadhaar-front-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.aadhaarFrontImage || "/placeholder.svg"}
                        alt="Aadhaar Card Front"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              {data.aadhaarBackImage && (
                <div className="hidden" id="aadhaar-back-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.aadhaarBackImage || "/placeholder.svg"}
                        alt="Aadhaar Card Back"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              {data.panImage && (
                <div className="hidden" id="pan-print">
                  <div className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm">
                    <div className="flex justify-center items-center h-full">
                      <img
                        src={data.panImage || "/placeholder.svg"}
                        alt="PAN Card"
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="kyc-info-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                  KYC Document
                </h2>

                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Name:</div>
                    <div className="col-span-2">{data.businessName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Address:</div>
                    <div className="col-span-2">{data.placeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Name:</div>
                    <div className="col-span-2">{data.authorityName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Father's Name:</div>
                    <div className="col-span-2">{data.authorityFatherName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Home Address:</div>
                    <div className="col-span-2">{data.homeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Contact Number:</div>
                    <div className="col-span-2">{data.contactNo}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Email:</div>
                    <div className="col-span-2">{data.email}</div>
                  </div>

                  {isManufacturing && data.productType && data.manufacturingCapacity && (
                    <>
                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Product Type:</div>
                        <div className="col-span-2">{data.productType}</div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Manufacturing Capacity:</div>
                        <div className="col-span-2">{data.manufacturingCapacity}</div>
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Name:</div>
                    <div className="col-span-2">{data.nomineeName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Relation:</div>
                    <div className="col-span-2">{data.nomineeRelation}</div>
                  </div>
                </div>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Date: {formatDate(data.date)}</p>
                </div>
              </div>

              {/* Visible KYC document with all images */}
              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="kyc-print"
              >
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                  <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                  <p className="text-sm text-center w-full">
                    Mail ID: {data.email} | Mo Number: {data.contactNo}
                  </p>
                </div>

                <h2 className="text-lg font-bold text-center mb-6">KYC Document</h2>

                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Name:</div>
                    <div className="col-span-2">{data.businessName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Business Address:</div>
                    <div className="col-span-2">{data.placeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Name:</div>
                    <div className="col-span-2">{data.authorityName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Father's Name:</div>
                    <div className="col-span-2">{data.authorityFatherName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Proprietor Home Address:</div>
                    <div className="col-span-2">{data.homeAddress}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Contact Number:</div>
                    <div className="col-span-2">{data.contactNo}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Email:</div>
                    <div className="col-span-2">{data.email}</div>
                  </div>

                  {isManufacturing && data.productType && data.manufacturingCapacity && (
                    <>
                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Product Type:</div>
                        <div className="col-span-2">{data.productType}</div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                        <div className="font-semibold text-gray-700">Manufacturing Capacity:</div>
                        <div className="col-span-2">{data.manufacturingCapacity}</div>
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Name:</div>
                    <div className="col-span-2">{data.nomineeName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold text-gray-700">Nominee Relation:</div>
                    <div className="col-span-2">{data.nomineeRelation}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">Aadhaar Card (Front):</div>
                    <div className="col-span-2">
                      {data.aadhaarFrontImage ? (
                        <img
                          src={data.aadhaarFrontImage || "/placeholder.svg"}
                          alt="Aadhaar Card Front"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">Aadhaar Card (Back):</div>
                    <div className="col-span-2">
                      {data.aadhaarBackImage ? (
                        <img
                          src={data.aadhaarBackImage || "/placeholder.svg"}
                          alt="Aadhaar Card Back"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-b border-gray-200 pb-3 mb-3">
                    <div className="font-semibold">PAN Card:</div>
                    <div className="col-span-2">
                      {data.panImage ? (
                        <img
                          src={data.panImage || "/placeholder.svg"}
                          alt="PAN Card"
                          className="h-32 object-contain border-2 border-gray-300 p-3 rounded-md shadow-sm"
                        />
                      ) : (
                        <p className="text-gray-500">Not provided</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <p className="mb-1">Signatures of the proprietor with Stamp Seal</p>

                  <div className="flex items-center gap-4 mb-4">
                    {data.stampImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.stampImage || "/placeholder.svg"}
                          alt="Proprietor Stamp"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {data.signatureImage && (
                      <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                        <img
                          src={data.signatureImage || "/placeholder.svg"}
                          alt="Proprietor Signature"
                          className="h-20 object-contain"
                        />
                      </div>
                    )}
                    {!data.stampImage && !data.signatureImage && (
                      <div className="h-16 border-b border-dashed w-full"></div>
                    )}
                  </div>

                  <p>Date: {formatDate(data.date)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="proprietorship">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={generateCompleteProprietorshipPDF}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="proprietorship-print"
              >
                <div id="proprietorship-content">
                  <div id="proprietorship-header" className="text-center mb-8">
                    <h1 className="text-3xl font-bold uppercase mb-4 text-blue-700">{data.businessName}</h1>
                    <p className="text-sm whitespace-pre-line text-center w-full">{data.placeAddress}</p>
                    <p className="text-sm text-center w-full">
                      Mail ID: {data.email} | Mo Number: {data.contactNo}
                    </p>
                    <h2 className="text-lg font-bold text-center mt-6 mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                      Proprietorship
                    </h2>
                  </div>

                  <div id="proprietorship-table" className="overflow-x-auto mb-8">
                    <table className="w-full border-collapse border border-gray-300" style={{ tableLayout: "fixed" }}>
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "8%" }}>
                            Sl.no
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "18%" }}>
                            Name of the partners*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "18%" }}>
                            Address
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Contact no.*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Description*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            ID Details*
                          </th>
                          <th className="border border-gray-300 p-3 text-left font-semibold" style={{ width: "14%" }}>
                            Date of appointment
                          </th>
                        </tr>
                      </thead>
                      <tbody>{renderPartners()}</tbody>
                    </table>
                  </div>

                  <div id="proprietorship-signature" className="mt-8 text-right">
                    <p className="mb-1 text-right">Signature of the authorized signatory</p>
                    <p className="text-right">(Along with seal of Proprietorship firm)</p>

                    <div className="flex justify-end items-center gap-4 mb-4">
                      {data.stampImage && (
                        <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                          <img
                            src={data.stampImage || "/placeholder.svg"}
                            alt="Proprietor Stamp"
                            className="h-20 object-contain"
                          />
                        </div>
                      )}
                      {data.signatureImage && (
                        <div className="border-2 border-gray-300 p-3 rounded-md shadow-sm">
                          <img
                            src={data.signatureImage || "/placeholder.svg"}
                            alt="Proprietor Signature"
                            className="h-20 object-contain"
                          />
                        </div>
                      )}
                      {!data.stampImage && !data.signatureImage && (
                        <div className="h-16 border-b border-dashed w-32"></div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="authority-letter">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-end space-x-2 mb-4">
                <Button variant="outline" onClick={handlePrint} className="flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const { id, fileName } = getCurrentDocumentInfo()
                    handleDownload(id, fileName)
                  }}
                  className="flex items-center gap-2"
                  disabled={isGeneratingPdf}
                >
                  {isGeneratingPdf ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-1"></span>
                      Generating PDF...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4" />
                      Download PDF
                    </>
                  )}
                </Button>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">Owner Name (for NOC)</label>
                <Input
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="Enter property owner's name"
                  className="max-w-md"
                />
              </div>

              <div
                className="bg-white p-10 border-2 border-gray-200 rounded-lg print:shadow-none shadow-sm"
                id="authority-letter-print"
              >
                

                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-center mt-6 mb-8 border-b-2 border-gray-300 pb-2 inline-block">
                    No Objection Certificate
                  </h2>
                </div>

                <div className="w-full text-center mb-8 concern-text">
                  <p className="font-semibold text-xl text-center w-full inline-block">TO WHOMSOEVER IT MAY CONCERN</p>
                </div>

                <p className="mb-4 text-justify">
                  This is to certify that I {ownerName} S/O {data.authorityFatherName} (Name of the owner), owner of the
                  property, {data.placeAddress} (Principal address)
                </p>

                <p className="mb-4 text-justify">
                  Further I have permitted {data.businessName}, represented by {data.authorityName} (Proprietor), to use
                  the above-mentioned property for business purpose. It is hereby solemnly affirmed that I have no
                  objection in the above property being used for the business purposes.
                </p>

                <p className="mb-4 text-justify">
                  This no objection certificate is issued for the purposes of obtaining any registrations as per the
                  local tax laws
                </p>

                <div className="mt-8 grid grid-cols-2 gap-8">
                  <div>
                    <p className="mb-1">Owner of the property</p>
                    <div className="h-16 border-b border-dashed w-full mb-4"></div>
                    <p>Signature</p>
                    <p>{ownerName}</p>
                  </div>

                  <div>
                    <p className="mb-1">Proprietor</p>
                    <div className="h-16 border-b border-dashed w-full mb-4"></div>
                    <p>Signature</p>
                    <p>{data.authorityName}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
