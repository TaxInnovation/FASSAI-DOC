import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import TradingForm from "@/components/trading-form"
import ManufacturingForm from "@/components/manufacturing-form"

export default function Home() {
  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">FSSAI Form Application</h1>

      <Tabs defaultValue="trading" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="trading">Trading</TabsTrigger>
          <TabsTrigger value="manufacturing">Manufacturing</TabsTrigger>
        </TabsList>

        <TabsContent value="trading">
          <TradingForm />
        </TabsContent>

        <TabsContent value="manufacturing">
          <ManufacturingForm />
        </TabsContent>
      </Tabs>
    </div>
  )
}
